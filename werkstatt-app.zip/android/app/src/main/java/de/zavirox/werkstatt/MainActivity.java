package de.zavirox.werkstatt;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
