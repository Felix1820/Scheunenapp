# Werkstatt

Offline-App für die Werkstatt in der Scheune: Lager, Werkzeug, Projekte, Zeit & Kosten,
QR-Etiketten und Handwerker-Rechner. Alle Daten liegen lokal auf dem Gerät (IndexedDB),
es wird nichts ins Internet geschickt.

## Aufbau

    www/            die eigentliche App (reines HTML/CSS/JavaScript, kein Build nötig)
      index.html
      styles.css
      js/           db, util, media (Kamera/Mikrofon/QR), lager, werkzeug, projekte,
                    kosten, rechner, etiketten, einkauf, backup, app
      vendor/       qrcode.js (Etiketten erzeugen), jsqr.js (QR scannen)
    android/        Capacitor-Projekt für die Android-App
    .github/workflows/build-apk.yml   baut bei jedem Push automatisch eine APK

## Im Browser testen

    npx http-server www -p 8080
    # oder
    python3 -m http.server 8080 --directory www

## APK bauen

Automatisch: Repo zu GitHub pushen – der Workflow baut die APK und hängt sie
als Release-Datei (`werkstatt.apk`) an.

Lokal (mit installiertem Android SDK):

    npm install
    npx cap sync android
    cd android && ./gradlew assembleDebug
    # Ergebnis: android/app/build/outputs/apk/debug/app-debug.apk

## Berechtigungen

Kamera (QR-Codes, Fotos), Mikrofon (Sprachnotizen), Vibration.
Kein Internetzugriff nötig.
