/* ---------------------------------------------------------------
   media.js – Fotos, Sprachnotizen, QR-Scanner
----------------------------------------------------------------*/
const Media = (function () {
  const urlCache = {};

  /* ---------- Speicher ---------- */
  async function save(blob, typ, extra) {
    const rec = Object.assign({
      id: Util.uid(), typ: typ, blob: blob,
      mime: blob.type || '', size: blob.size, erstellt: Date.now()
    }, extra || {});
    await DB.put('medien', rec);
    return rec.id;
  }

  async function url(id) {
    if (urlCache[id]) return urlCache[id];
    const rec = await DB.get('medien', id);
    if (!rec || !rec.blob) return null;
    const u = URL.createObjectURL(rec.blob);
    urlCache[id] = u;
    return u;
  }

  async function remove(id) {
    if (urlCache[id]) { URL.revokeObjectURL(urlCache[id]); delete urlCache[id]; }
    await DB.del('medien', id);
  }

  /* Bilder in <img data-media="id"> nachladen */
  async function hydrate(root) {
    const imgs = Util.$$('img[data-media]', root || document);
    for (const img of imgs) {
      const u = await url(img.dataset.media);
      if (u) img.src = u;
      img.removeAttribute('data-media');
    }
  }

  /* ---------- Foto aufnehmen / wählen ---------- */
  function pickPhoto() {
    return new Promise(resolve => {
      const inp = document.createElement('input');
      inp.type = 'file';
      inp.accept = 'image/*';
      inp.setAttribute('capture', 'environment');
      inp.style.display = 'none';
      document.body.appendChild(inp);
      let done = false;
      inp.onchange = async () => {
        done = true;
        const file = inp.files && inp.files[0];
        inp.remove();
        if (!file) return resolve(null);
        try {
          const blob = await shrink(file, 1400, 0.72);
          const id = await save(blob, 'foto');
          resolve(id);
        } catch (e) {
          Util.toast('Foto konnte nicht gespeichert werden');
          resolve(null);
        }
      };
      // Falls der Nutzer abbricht, Input wieder aufräumen
      setTimeout(() => { if (!done && inp.isConnected && !inp.files.length) { /* bleibt bis onchange */ } }, 500);
      inp.click();
    });
  }

  /* Bild verkleinern, spart Speicher auf dem Handy */
  function shrink(file, maxSide, quality) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const u = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(u);
        let w = img.naturalWidth, h = img.naturalHeight;
        const scale = Math.min(1, maxSide / Math.max(w, h));
        w = Math.round(w * scale); h = Math.round(h * scale);
        const c = document.createElement('canvas');
        c.width = w; c.height = h;
        c.getContext('2d').drawImage(img, 0, 0, w, h);
        c.toBlob(b => b ? resolve(b) : reject(new Error('toBlob')), 'image/jpeg', quality);
      };
      img.onerror = () => { URL.revokeObjectURL(u); reject(new Error('load')); };
      img.src = u;
    });
  }

  /* ---------- Sprachnotiz ---------- */
  function recordAudio() {
    return new Promise(async resolve => {
      let stream, rec, chunks = [], startTs = 0, tick = null, finished = false;
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      } catch (e) {
        Util.toast('Kein Zugriff aufs Mikrofon');
        return resolve(null);
      }
      let mime = '';
      ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg'].some(m => {
        if (window.MediaRecorder && MediaRecorder.isTypeSupported(m)) { mime = m; return true; }
        return false;
      });
      try {
        rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
      } catch (e) {
        stream.getTracks().forEach(t => t.stop());
        Util.toast('Aufnahme wird nicht unterstützt');
        return resolve(null);
      }

      Util.sheet('Sprachnotiz', [
        '<div class="center stack">',
        '<p class="timer-big" id="recTime">00:00:00</p>',
        '<p class="muted small"><span class="dot"></span> Aufnahme läuft …</p>',
        '<div class="btn-row"><button class="btn" id="recCancel">Verwerfen</button>',
        '<button class="btn btn-primary" id="recStop">Fertig</button></div>',
        '</div>'
      ].join(''), el => {
        const timeEl = Util.$('#recTime', el);
        tick = setInterval(() => { timeEl.textContent = Util.durClock(Date.now() - startTs); }, 500);
        Util.$('#recStop', el).onclick = () => { finished = true; stop(); };
        Util.$('#recCancel', el).onclick = () => { finished = false; stop(); };
      });

      function stop() {
        try { if (rec.state !== 'inactive') rec.stop(); } catch (e) {}
      }

      rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
      rec.onstop = async () => {
        clearInterval(tick);
        stream.getTracks().forEach(t => t.stop());
        Util.closeSheet();
        if (!finished || !chunks.length) return resolve(null);
        const blob = new Blob(chunks, { type: mime || 'audio/webm' });
        const id = await save(blob, 'audio', { dauer: Date.now() - startTs });
        resolve(id);
      };
      startTs = Date.now();
      rec.start();
    });
  }

  /* ---------- QR-Scanner ---------- */
  let scanStream = null, scanRaf = null, scanResolve = null;

  function scan(hint) {
    return new Promise(async resolve => {
      const box = Util.$('#scanner');
      const video = Util.$('#scanVideo');
      Util.$('#scanHint').textContent = hint || 'QR-Code ins Feld halten';
      scanResolve = resolve;
      try {
        scanStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' } }, audio: false
        });
      } catch (e) {
        Util.toast('Kein Zugriff auf die Kamera');
        scanResolve = null;
        return resolve(null);
      }
      box.classList.remove('hidden');
      video.srcObject = scanStream;
      video.setAttribute('playsinline', '');
      try { await video.play(); } catch (e) {}

      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d', { willReadFrequently: true });

      function loop() {
        if (!scanStream) return;
        if (video.readyState === video.HAVE_ENOUGH_DATA) {
          const w = video.videoWidth, h = video.videoHeight;
          if (w && h) {
            const side = Math.min(w, h);
            canvas.width = side; canvas.height = side;
            ctx.drawImage(video, (w - side) / 2, (h - side) / 2, side, side, 0, 0, side, side);
            const data = ctx.getImageData(0, 0, side, side);
            const code = window.jsQR ? jsQR(data.data, data.width, data.height,
              { inversionAttempts: 'dontInvert' }) : null;
            if (code && code.data) {
              if (navigator.vibrate) navigator.vibrate(60);
              const val = code.data;
              stopScan();
              if (scanResolve) { const r = scanResolve; scanResolve = null; r(val); }
              return;
            }
          }
        }
        scanRaf = requestAnimationFrame(loop);
      }
      scanRaf = requestAnimationFrame(loop);
    });
  }

  function stopScan() {
    if (scanRaf) cancelAnimationFrame(scanRaf);
    scanRaf = null;
    if (scanStream) { scanStream.getTracks().forEach(t => t.stop()); scanStream = null; }
    const v = Util.$('#scanVideo');
    if (v) v.srcObject = null;
    Util.$('#scanner').classList.add('hidden');
  }

  function cancelScan() {
    stopScan();
    if (scanResolve) { const r = scanResolve; scanResolve = null; r(null); }
  }

  return { save, url, remove, hydrate, pickPhoto, recordAudio, scan, cancelScan, shrink };
})();
