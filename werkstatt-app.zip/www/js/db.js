/* ---------------------------------------------------------------
   db.js – IndexedDB Speicher. Alles liegt lokal auf dem Handy,
   funktioniert komplett ohne Netz.
----------------------------------------------------------------*/
const DB = (function () {
  const NAME = 'werkstatt';
  const VERSION = 1;
  const STORES = {
    material: 'id',
    werkzeug: 'id',
    projekte: 'id',
    orte: 'id',
    medien: 'id',
    meta: 'k'
  };
  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(NAME, VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        Object.keys(STORES).forEach(name => {
          if (!db.objectStoreNames.contains(name)) {
            db.createObjectStore(name, { keyPath: STORES[name] });
          }
        });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  function run(store, mode, fn) {
    return open().then(db => new Promise((resolve, reject) => {
      const t = db.transaction(store, mode);
      const s = t.objectStore(store);
      let out;
      const r = fn(s);
      if (r) r.onsuccess = () => { out = r.result; };
      t.oncomplete = () => resolve(out);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error);
    }));
  }

  const api = {
    all: (store) => run(store, 'readonly', s => s.getAll()),
    get: (store, id) => run(store, 'readonly', s => s.get(id)),
    put: (store, obj) => run(store, 'readwrite', s => s.put(obj)).then(() => obj),
    del: (store, id) => run(store, 'readwrite', s => s.delete(id)),
    clear: (store) => run(store, 'readwrite', s => s.clear()),
    stores: Object.keys(STORES),

    /* --- Einstellungen --- */
    async setting(key, fallback) {
      const row = await api.get('meta', key);
      return row === undefined ? fallback : row.v;
    },
    async setSetting(key, v) {
      await api.put('meta', { k: key, v: v });
      return v;
    },

    /* --- Speichern mit Zeitstempel --- */
    save(store, obj) {
      if (!obj.id) obj.id = Util.uid();
      if (!obj.erstellt) obj.erstellt = Date.now();
      obj.geaendert = Date.now();
      return api.put(store, obj);
    }
  };
  return api;
})();
