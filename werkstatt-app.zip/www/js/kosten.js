/* ---------------------------------------------------------------
   kosten.js – Zeit & Kosten je Projekt, Auswertung, CSV
----------------------------------------------------------------*/
const Kosten = (function () {
  let zeitraum = 'alle';

  function calc(p, satz) {
    const zeitMs = (p.zeiten || []).reduce((s, z) => s + Util.num(z.dauer), 0);
    const stunden = zeitMs / 3600000;
    const lohn = Math.round(stunden * Util.num(satz) * 100) / 100;
    const material = Math.round((p.material || []).reduce((s, m) => s + Util.num(m.kosten), 0) * 100) / 100;
    return { zeitMs: zeitMs, stunden: stunden, lohn: lohn, material: material,
             gesamt: Math.round((lohn + material) * 100) / 100 };
  }

  function grenze() {
    const d = new Date(); d.setHours(0, 0, 0, 0);
    if (zeitraum === 'woche') {
      const wd = (d.getDay() + 6) % 7;      // Montag = 0
      return d.getTime() - wd * 86400000;
    }
    if (zeitraum === 'monat') return new Date(d.getFullYear(), d.getMonth(), 1).getTime();
    if (zeitraum === 'jahr') return new Date(d.getFullYear(), 0, 1).getTime();
    return 0;
  }

  /* Projekt auf den Zeitraum zusammenschneiden */
  function imZeitraum(p, ab) {
    if (!ab) return p;
    return Object.assign({}, p, {
      zeiten: (p.zeiten || []).filter(z => z.start >= ab),
      material: (p.material || []).filter(m => (m.ts || p.erstellt || 0) >= ab)
    });
  }

  async function view() {
    const satzDefault = await DB.setting('stundensatz', 0);
    const alle = await DB.all('projekte');
    const ab = grenze();
    const rows = alle.map(p => {
      const satz = Util.num(p.stundensatz) || satzDefault;
      return { p: p, satz: satz, k: calc(imZeitraum(p, ab), satz) };
    }).filter(r => r.k.zeitMs > 0 || r.k.material > 0)
      .sort((a, b) => b.k.gesamt - a.k.gesamt);

    const sum = rows.reduce((s, r) => ({
      zeitMs: s.zeitMs + r.k.zeitMs, lohn: s.lohn + r.k.lohn,
      material: s.material + r.k.material, gesamt: s.gesamt + r.k.gesamt
    }), { zeitMs: 0, lohn: 0, material: 0, gesamt: 0 });

    const chips = [['woche', 'Diese Woche'], ['monat', 'Dieser Monat'], ['jahr', 'Dieses Jahr'], ['alle', 'Alles']]
      .map(c => '<button class="chip' + (zeitraum === c[0] ? ' on' : '') + '" data-z="' + c[0] + '">' + c[1] + '</button>').join('');

    const maxG = Math.max.apply(null, rows.map(r => r.k.gesamt).concat([1]));

    const html = [
      '<div class="chips">' + chips + '</div>',
      '<div class="card">',
      '<div class="between"><span class="muted">Arbeitszeit</span><span class="timer-big" style="font-size:26px">' + Util.dur(sum.zeitMs) + '</span></div>',
      '<hr>',
      kv2('Arbeitswert (' + Util.eur(satzDefault) + '/h)', Util.eur(sum.lohn)),
      kv2('Materialkosten', Util.eur(sum.material)),
      '<div class="kv"><span class="k"><b>Gesamtwert</b></span><span class="v" style="color:var(--accent);font-size:18px">' + Util.eur(sum.gesamt) + '</span></div>',
      '</div>',
      rows.length ? '<h2>Nach Projekt</h2>' + rows.map(r => [
        '<div class="card tight">',
        '<div class="between"><b>' + Util.esc(r.p.name) + '</b><span style="color:var(--accent);font-weight:700">' + Util.eur(r.k.gesamt) + '</span></div>',
        '<div class="small muted">' + Util.dur(r.k.zeitMs) + ' · Material ' + Util.eur(r.k.material) + '</div>',
        '<div class="bar"><i style="width:' + Math.max(3, (r.k.gesamt / maxG) * 100) + '%;background:var(--accent)"></i></div>',
        '</div>'
      ].join('')).join('') : '<div class="empty">Für diesen Zeitraum ist nichts erfasst.</div>',
      '<div class="btn-row" style="margin-top:14px"><button class="btn" id="kCsv">Als CSV teilen</button>',
      '<button class="btn" id="kSatz">Stundensatz</button></div>'
    ].join('');

    App.paint('Zeit & Kosten', html, el => {
      App.showBack('mehr');
      Util.$$('.chip', el).forEach(c => { c.onclick = () => { zeitraum = c.dataset.z; view(); }; });
      Util.$('#kCsv', el).onclick = () => csv(rows);
      Util.$('#kSatz', el).onclick = () => stundensatzDialog();
    });
  }

  function kv2(k, v) {
    return '<div class="kv"><span class="k">' + Util.esc(k) + '</span><span class="v">' + Util.esc(v) + '</span></div>';
  }

  async function stundensatzDialog() {
    const satz = await DB.setting('stundensatz', 0);
    Util.sheet('Stundensatz', [
      '<p class="muted small">Damit rechnet die App den Arbeitswert deiner Projekte aus. Einzelne Projekte können einen eigenen Satz haben.</p>',
      '<div class="field"><label>Standard-Stundensatz (€)</label><input name="satz" type="text" inputmode="decimal" value="' + (satz ? Util.fmt(satz, 2) : '') + '"></div>',
      '<div class="btn-row"><button class="btn" id="ssAb">Abbrechen</button>',
      '<button class="btn btn-primary" id="ssOk">Speichern</button></div>'
    ].join(''), el => {
      Util.$('#ssAb', el).onclick = Util.closeSheet;
      Util.$('#ssOk', el).onclick = async () => {
        await DB.setSetting('stundensatz', Util.num(Util.formData(el).satz));
        Util.closeSheet(); Util.toast('Gespeichert');
        if (App.route === 'kosten') view();
      };
    });
  }

  function csv(rows) {
    const lines = [['Projekt', 'Auftraggeber', 'Status', 'Stunden', 'Stundensatz', 'Arbeitswert', 'Material', 'Gesamt'].join(';')];
    rows.forEach(r => {
      lines.push([
        '"' + r.p.name.replace(/"/g, '""') + '"',
        '"' + (r.p.kunde || '').replace(/"/g, '""') + '"',
        (Projekte.STATUS[r.p.status || 'offen'] || {}).label || '',
        Util.fmt(r.k.stunden, 2), Util.fmt(r.satz, 2), Util.fmt(r.k.lohn, 2),
        Util.fmt(r.k.material, 2), Util.fmt(r.k.gesamt, 2)
      ].join(';'));
    });
    const name = 'werkstatt-kosten-' + Util.dateInput() + '.csv';
    App.teilen(new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv' }), name, 'Zeit & Kosten');
  }

  return { view, calc, stundensatzDialog };
})();
