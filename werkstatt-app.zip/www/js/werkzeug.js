/* ---------------------------------------------------------------
   werkzeug.js – Werkzeug: Ort, Zustand, Verleih, Wartung
----------------------------------------------------------------*/
const Werkzeug = (function () {
  let filter = { q: '', kat: '', spezial: '' };

  const ZUSTAND = {
    ok:      { label: 'Einsatzbereit', cls: 'b-ok' },
    wartung: { label: 'Wartung nötig', cls: 'b-warn' },
    defekt:  { label: 'Defekt',        cls: 'b-danger' }
  };

  function wartungFaellig(w) {
    const d = Util.daysUntil(w.wartungFaellig);
    return d !== null && d <= 7;
  }
  function problemeVon(w) {
    const out = [];
    if (w.verliehenAn) out.push({ text: 'verliehen an ' + w.verliehenAn, kurz: 'verliehen', cls: 'b-info' });
    if (w.zustand === 'defekt') out.push({ text: 'defekt', kurz: 'defekt', cls: 'b-danger' });
    else if (w.zustand === 'wartung') out.push({ text: 'Wartung nötig', kurz: 'Wartung', cls: 'b-warn' });
    if (wartungFaellig(w)) out.push({ text: 'Wartung ' + Util.relTag(w.wartungFaellig), kurz: 'Wartung', cls: 'b-warn' });
    return out;
  }
  async function warnungen() {
    const all = await DB.all('werkzeug');
    return all.filter(w => w.verliehenAn || w.zustand === 'defekt' || w.zustand === 'wartung' || wartungFaellig(w));
  }

  /* ---------- Liste ---------- */
  async function view() {
    const all = Util.sortBy(await DB.all('werkzeug'), 'name');
    const kats = Array.from(new Set(all.map(w => w.kategorie).filter(Boolean))).sort((a, b) => a.localeCompare(b, 'de'));
    const nVerliehen = all.filter(w => w.verliehenAn).length;
    const nWartung = all.filter(w => wartungFaellig(w) || w.zustand === 'wartung').length;
    const nDefekt = all.filter(w => w.zustand === 'defekt').length;

    let list = all;
    if (filter.spezial === 'verliehen') list = list.filter(w => w.verliehenAn);
    else if (filter.spezial === 'wartung') list = list.filter(w => wartungFaellig(w) || w.zustand === 'wartung');
    else if (filter.spezial === 'defekt') list = list.filter(w => w.zustand === 'defekt');
    if (filter.kat) list = list.filter(w => w.kategorie === filter.kat);
    if (filter.q) {
      const q = filter.q.toLowerCase();
      list = list.filter(w => (w.name + ' ' + (w.kategorie || '') + ' ' + (w.ort || '')).toLowerCase().includes(q));
    }

    const chip = (key, label, n) =>
      '<button class="chip' + ((filter.spezial === key && !filter.kat) || (key === '' && !filter.spezial && !filter.kat) ? ' on' : '') +
      '" data-spezial="' + key + '">' + label + (n ? ' (' + n + ')' : '') + '</button>';

    const chips = [chip('', 'Alle'), chip('verliehen', 'Verliehen', nVerliehen),
      chip('wartung', 'Wartung', nWartung), chip('defekt', 'Defekt', nDefekt)]
      .concat(kats.map(k => '<button class="chip' + (filter.kat === k ? ' on' : '') + '" data-kat="' + Util.esc(k) + '">' + Util.esc(k) + '</button>'))
      .join('');

    const html = [
      '<div class="search"><input id="wSuche" type="search" placeholder="Werkzeug suchen …" value="' + Util.esc(filter.q) + '"></div>',
      '<div class="chips">' + chips + '</div>',
      all.length === 0
        ? '<div class="empty"><span class="big">&#9874;</span>Noch kein Werkzeug erfasst.<br>Mit <b>+</b> anlegen – dann weißt du immer, wo es liegt.</div>'
        : (list.length === 0 ? '<div class="empty">Nichts gefunden.</div>' : '<div class="list">' + list.map(rowHtml).join('') + '</div>'),
      '<button class="fab" id="wAdd">+</button>'
    ].join('');

    App.paint('Werkzeug', html, el => {
      const s = Util.$('#wSuche', el);
      s.oninput = Util.debounce(() => { filter.q = s.value; view(); }, 250);
      Util.$$('.chip', el).forEach(c => {
        c.onclick = () => {
          if (c.dataset.kat !== undefined) { filter.kat = c.dataset.kat; filter.spezial = ''; }
          else { filter.spezial = c.dataset.spezial; filter.kat = ''; }
          view();
        };
      });
      Util.$$('.item', el).forEach(it => { it.onclick = () => detail(it.dataset.id); });
      Util.$('#wAdd', el).onclick = () => form();
      Media.hydrate(el);
    });
  }

  function rowHtml(w) {
    const probs = problemeVon(w);
    const sub = [w.ort || 'kein Ort hinterlegt', w.kategorie].filter(Boolean).map(Util.esc).join(' · ');
    return [
      '<button class="item" data-id="' + w.id + '">',
      w.fotoId ? '<img class="thumb" data-media="' + w.fotoId + '" alt="">' : '<span class="avatar">&#9874;</span>',
      '<span class="main"><span class="name">' + Util.esc(w.name) + '</span>',
      '<span class="sub">' + sub + '</span></span>',
      probs.length
        ? '<span class="badge ' + probs[0].cls + '">' + Util.esc(probs[0].kurz || probs[0].text) + '</span>'
        : '<span class="badge b-ok">da</span>',
      '</button>'
    ].join('');
  }

  /* ---------- Detail ---------- */
  async function detail(id) {
    const w = await DB.get('werkzeug', id);
    if (!w) { Util.toast('Werkzeug nicht gefunden'); return; }
    const z = ZUSTAND[w.zustand || 'ok'];

    const html = [
      w.fotoId ? '<img data-media="' + w.fotoId + '" style="width:100%;max-height:190px;object-fit:cover;border-radius:12px;margin-bottom:12px" alt="">' : '',
      '<div class="row wrap" style="margin-bottom:12px">',
      '<span class="badge ' + z.cls + '">' + z.label + '</span>',
      w.verliehenAn ? '<span class="badge b-info">verliehen an ' + Util.esc(w.verliehenAn) + '</span>' : '',
      w.wartungFaellig ? '<span class="badge ' + (wartungFaellig(w) ? 'b-warn' : 'b-grey') + '">Wartung ' + Util.relTag(w.wartungFaellig) + '</span>' : '',
      '</div>',
      '<div class="card tight">',
      kv('Ort', w.ort),
      kv('Kategorie', w.kategorie),
      kv('Wartung fällig', w.wartungFaellig ? Util.date(w.wartungFaellig) : '–'),
      kv('Wartungsintervall', Util.num(w.intervall) ? Util.num(w.intervall) + ' Tage' : '–'),
      w.verliehenAn ? kv('Verliehen seit', Util.date(w.verliehenSeit)) : '',
      kv('Gekauft', w.kaufdatum ? Util.date(w.kaufdatum) : '–'),
      kv('Kaufpreis', Util.num(w.kaufpreis) ? Util.eur(w.kaufpreis) : '–'),
      kv('Seriennummer', w.seriennr),
      '</div>',
      w.notiz ? '<div class="card"><p class="small muted">Notiz</p><p style="margin:0;white-space:pre-wrap">' + Util.esc(w.notiz) + '</p></div>' : '',
      '<div class="stack" style="margin-top:12px">',
      w.verliehenAn
        ? '<button class="btn btn-primary btn-block" id="wBack">Ist zurück</button>'
        : '<button class="btn btn-block" id="wLend">Verleihen</button>',
      '<div class="btn-row"><button class="btn" id="wWartung">Wartung erledigt</button>',
      '<button class="btn" id="wZustand">Zustand ändern</button></div>',
      '<div class="btn-row"><button class="btn" id="wEdit">Bearbeiten</button>',
      '<button class="btn" id="wQr">QR-Etikett</button></div>',
      '<button class="btn btn-danger btn-block" id="wDel">Löschen</button>',
      '</div>'
    ].join('');

    Util.sheet(w.name, html, el => {
      Media.hydrate(el);
      const bBack = Util.$('#wBack', el);
      if (bBack) bBack.onclick = async () => {
        w.verliehenAn = ''; w.verliehenSeit = null;
        await DB.save('werkzeug', w); Util.toast('Wieder da'); detail(id); view();
      };
      const bLend = Util.$('#wLend', el);
      if (bLend) bLend.onclick = () => verleihen(w);
      Util.$('#wWartung', el).onclick = async () => {
        const iv = Util.num(w.intervall);
        w.zustand = 'ok';
        w.wartungZuletzt = Date.now();
        w.wartungFaellig = iv > 0 ? Date.now() + iv * 86400000 : null;
        await DB.save('werkzeug', w);
        Util.toast(iv > 0 ? 'Erledigt – nächste Wartung ' + Util.date(w.wartungFaellig) : 'Wartung erledigt');
        detail(id); view();
      };
      Util.$('#wZustand', el).onclick = () => zustandWaehlen(w);
      Util.$('#wEdit', el).onclick = () => form(w.id);
      Util.$('#wQr', el).onclick = () => { Util.closeSheet(); Etiketten.single('werkzeug', w.id, w.name); };
      Util.$('#wDel', el).onclick = async () => {
        if (await Util.confirm('„' + w.name + '“ wirklich löschen?')) {
          if (w.fotoId) await Media.remove(w.fotoId);
          await DB.del('werkzeug', w.id);
          Util.closeSheet(); Util.toast('Gelöscht'); view();
        }
      };
    });
  }

  function verleihen(w) {
    Util.sheet('Verleihen: ' + w.name, [
      '<div class="field"><label>An wen?</label><input name="an" placeholder="Name" autocomplete="off"></div>',
      '<div class="field"><label>Seit</label><input name="seit" type="date" value="' + Util.dateInput() + '"></div>',
      '<div class="btn-row"><button class="btn" id="vAb">Abbrechen</button>',
      '<button class="btn btn-primary" id="vOk">Verliehen</button></div>'
    ].join(''), el => {
      Util.$('#vAb', el).onclick = () => detail(w.id);
      Util.$('#vOk', el).onclick = async () => {
        const d = Util.formData(el);
        if (!d.an.trim()) { Util.toast('Bitte einen Namen eintragen'); return; }
        w.verliehenAn = d.an.trim();
        w.verliehenSeit = Util.fromDateInput(d.seit) || Date.now();
        await DB.save('werkzeug', w);
        Util.toast('Notiert'); detail(w.id); view();
      };
    });
  }

  function zustandWaehlen(w) {
    Util.sheet('Zustand: ' + w.name,
      '<div class="stack">' + Object.keys(ZUSTAND).map(k =>
        '<button class="btn btn-block" data-z="' + k + '">' + ZUSTAND[k].label + '</button>').join('') + '</div>',
      el => {
        Util.$$('[data-z]', el).forEach(b => {
          b.onclick = async () => {
            w.zustand = b.dataset.z;
            await DB.save('werkzeug', w);
            Util.toast('Zustand: ' + ZUSTAND[w.zustand].label);
            detail(w.id); view();
          };
        });
      });
  }

  function kv(k, v) {
    if (v === undefined || v === null || v === '') v = '–';
    return '<div class="kv"><span class="k">' + Util.esc(k) + '</span><span class="v">' + Util.esc(v) + '</span></div>';
  }

  /* ---------- Formular ---------- */
  async function form(id) {
    const w = id ? await DB.get('werkzeug', id) : {
      name: '', kategorie: '', ort: '', zustand: 'ok', verliehenAn: '', verliehenSeit: null,
      wartungFaellig: null, intervall: '', kaufdatum: null, kaufpreis: '', seriennr: '', notiz: '', fotoId: null
    };
    const alle = await DB.all('werkzeug');
    const kats = Array.from(new Set(alle.map(x => x.kategorie).filter(Boolean)));
    const orte = Array.from(new Set(alle.map(x => x.ort).filter(Boolean)
      .concat((await DB.all('material')).map(m => m.ort).filter(Boolean))
      .concat((await DB.all('orte')).map(o => o.name))));

    const html = [
      '<div class="field"><label>Bezeichnung</label><input name="name" value="' + Util.esc(w.name) + '" placeholder="z. B. Akkuschrauber Makita"></div>',
      '<div class="field"><label>Lagerort</label><input name="ort" list="wOrtList" value="' + Util.esc(w.ort) + '" placeholder="z. B. Werkbank Schublade 2">',
      '<datalist id="wOrtList">' + orte.map(o => '<option value="' + Util.esc(o) + '">').join('') + '</datalist></div>',
      '<div class="field"><label>Kategorie</label><input name="kategorie" list="wKatList" value="' + Util.esc(w.kategorie) + '" placeholder="z. B. Elektrowerkzeug">',
      '<datalist id="wKatList">' + kats.map(k => '<option value="' + Util.esc(k) + '">').join('') + '</datalist></div>',
      '<div class="field"><label>Zustand</label><select name="zustand">' +
        Object.keys(ZUSTAND).map(k => '<option value="' + k + '"' + ((w.zustand || 'ok') === k ? ' selected' : '') + '>' + ZUSTAND[k].label + '</option>').join('') +
        '</select></div>',
      '<div class="fields2">',
      '<div class="field"><label>Wartung fällig am</label><input name="wartungFaellig" type="date" value="' + (w.wartungFaellig ? Util.dateInput(w.wartungFaellig) : '') + '"></div>',
      '<div class="field"><label>Intervall (Tage)</label><input name="intervall" type="text" inputmode="numeric" value="' + Util.esc(w.intervall || '') + '" placeholder="z. B. 180"></div>',
      '</div>',
      '<div class="fields2">',
      '<div class="field"><label>Gekauft am</label><input name="kaufdatum" type="date" value="' + (w.kaufdatum ? Util.dateInput(w.kaufdatum) : '') + '"></div>',
      '<div class="field"><label>Kaufpreis (€)</label><input name="kaufpreis" type="text" inputmode="decimal" value="' + (Util.num(w.kaufpreis) ? Util.fmt(w.kaufpreis, 2) : '') + '"></div>',
      '</div>',
      '<div class="field"><label>Seriennummer</label><input name="seriennr" value="' + Util.esc(w.seriennr) + '"></div>',
      '<div class="field"><label>Notiz</label><textarea name="notiz">' + Util.esc(w.notiz) + '</textarea></div>',
      '<div class="field"><label>Foto</label><div class="row">',
      w.fotoId ? '<img class="thumb" data-media="' + w.fotoId + '" alt="">' : '',
      '<button class="btn btn-sm" id="wFotoBtn" type="button">' + (w.fotoId ? 'Foto ersetzen' : 'Foto aufnehmen') + '</button>',
      '</div></div>',
      '<div class="btn-row"><button class="btn" id="wfAb">Abbrechen</button>',
      '<button class="btn btn-primary" id="wfOk">Speichern</button></div>'
    ].join('');

    Util.sheet(id ? 'Werkzeug bearbeiten' : 'Neues Werkzeug', html, el => {
      Media.hydrate(el);
      let fotoId = w.fotoId || null;
      Util.$('#wFotoBtn', el).onclick = async () => {
        const nid = await Media.pickPhoto();
        if (nid) { fotoId = nid; Util.toast('Foto gespeichert'); }
      };
      Util.$('#wfAb', el).onclick = () => id ? detail(id) : Util.closeSheet();
      Util.$('#wfOk', el).onclick = async () => {
        const d = Util.formData(el);
        if (!d.name.trim()) { Util.toast('Bitte eine Bezeichnung eintragen'); return; }
        Object.assign(w, {
          name: d.name.trim(), ort: d.ort.trim(), kategorie: d.kategorie.trim(),
          zustand: d.zustand, wartungFaellig: Util.fromDateInput(d.wartungFaellig),
          intervall: d.intervall.trim(), kaufdatum: Util.fromDateInput(d.kaufdatum),
          kaufpreis: d.kaufpreis === '' ? '' : Util.num(d.kaufpreis),
          seriennr: d.seriennr.trim(), notiz: d.notiz.trim(), fotoId: fotoId
        });
        await DB.save('werkzeug', w);
        Util.closeSheet(); Util.toast('Gespeichert');
        if (App.route === 'werkzeug') view(); else App.go('werkzeug');
      };
    });
  }

  return { view, detail, form, warnungen, problemeVon, wartungFaellig, ZUSTAND };
})();
