/* ---------------------------------------------------------------
   util.js – kleine Helfer: Formatieren, Dialoge, Toast
----------------------------------------------------------------*/
const Util = (function () {
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  function uid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function esc(s) {
    return String(s === undefined || s === null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  /* deutsche Kommazahl -> Number */
  function num(v) {
    if (typeof v === 'number') return v;
    if (v === undefined || v === null || v === '') return 0;
    const n = parseFloat(String(v).replace(/\s/g, '').replace(',', '.'));
    return isNaN(n) ? 0 : n;
  }

  function fmt(n, dec) {
    const d = dec === undefined ? 2 : dec;
    const x = num(n);
    let s = x.toFixed(d);
    if (d > 0) s = s.replace(/\.?0+$/, '');
    return s.replace('.', ',');
  }

  function eur(n) {
    return num(n).toFixed(2).replace('.', ',') + ' €';
  }

  const PAD = n => String(n).padStart(2, '0');

  function date(ts) {
    if (!ts) return '';
    const d = new Date(ts);
    return PAD(d.getDate()) + '.' + PAD(d.getMonth() + 1) + '.' + d.getFullYear();
  }
  function dateTime(ts) {
    if (!ts) return '';
    const d = new Date(ts);
    return date(ts) + ' ' + PAD(d.getHours()) + ':' + PAD(d.getMinutes());
  }
  function dateInput(ts) {
    const d = ts ? new Date(ts) : new Date();
    return d.getFullYear() + '-' + PAD(d.getMonth() + 1) + '-' + PAD(d.getDate());
  }
  function fromDateInput(s) {
    if (!s) return null;
    const p = s.split('-');
    return new Date(+p[0], +p[1] - 1, +p[2], 12, 0, 0).getTime();
  }
  function daysUntil(ts) {
    if (!ts) return null;
    const a = new Date(); a.setHours(0, 0, 0, 0);
    const b = new Date(ts); b.setHours(0, 0, 0, 0);
    return Math.round((b - a) / 86400000);
  }
  function relTag(ts) {
    const d = daysUntil(ts);
    if (d === null) return '';
    if (d < 0) return 'überfällig seit ' + (-d) + ' T';
    if (d === 0) return 'heute';
    if (d === 1) return 'morgen';
    return 'in ' + d + ' Tagen';
  }

  /* Dauer in ms -> "1:05 h" / "12 min" */
  function dur(ms) {
    const min = Math.floor(ms / 60000);
    if (min < 60) return min + ' min';
    return Math.floor(min / 60) + ':' + PAD(min % 60) + ' h';
  }
  function durClock(ms) {
    const s = Math.floor(ms / 1000);
    return PAD(Math.floor(s / 3600)) + ':' + PAD(Math.floor(s / 60) % 60) + ':' + PAD(s % 60);
  }
  function hours(ms) { return ms / 3600000; }

  /* ---------- Toast ---------- */
  let toastTimer = null;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.add('hidden'), 2400);
  }

  /* ---------- Sheet (Dialog von unten) ---------- */
  function sheet(title, html, onMount) {
    const wrap = $('#sheet');
    const inner = $('#sheetInner');
    inner.innerHTML = (title ? '<p class="sheet-title">' + esc(title) + '</p>' : '') + html;
    wrap.classList.remove('hidden');
    inner.scrollTop = 0;
    if (onMount) onMount(inner);
    return inner;
  }
  function closeSheet() {
    $('#sheet').classList.add('hidden');
    $('#sheetInner').innerHTML = '';
  }

  function confirmBox(text, okLabel) {
    return new Promise(resolve => {
      sheet('', '<p style="font-size:17px;margin:4px 0 18px">' + esc(text) + '</p>' +
        '<div class="btn-row"><button class="btn" id="cNo">Abbrechen</button>' +
        '<button class="btn btn-danger" id="cYes">' + esc(okLabel || 'Löschen') + '</button></div>',
        el => {
          $('#cNo', el).onclick = () => { closeSheet(); resolve(false); };
          $('#cYes', el).onclick = () => { closeSheet(); resolve(true); };
        });
    });
  }

  /* Formularwerte aus einem Container einsammeln */
  function formData(root) {
    const out = {};
    $$('[name]', root).forEach(f => {
      if (f.type === 'checkbox') out[f.name] = f.checked;
      else out[f.name] = f.value;
    });
    return out;
  }

  function debounce(fn, ms) {
    let t;
    return function () {
      const a = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(() => fn.apply(self, a), ms || 250);
    };
  }

  function sortBy(arr, key) {
    return arr.slice().sort((a, b) => {
      const x = a[key], y = b[key];
      if (typeof x === 'string') return x.localeCompare(y || '', 'de');
      return (x || 0) - (y || 0);
    });
  }

  return { $, $$, uid, esc, num, fmt, eur, date, dateTime, dateInput, fromDateInput,
           daysUntil, relTag, dur, durClock, hours, toast, sheet, closeSheet,
           confirm: confirmBox, formData, debounce, sortBy };
})();
