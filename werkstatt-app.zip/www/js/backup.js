/* ---------------------------------------------------------------
   backup.js – alles sichern und zurückholen (eine Datei, offline)
----------------------------------------------------------------*/
const Backup = (function () {
  const VERSION = 1;

  function blobToDataUrl(blob) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = () => rej(r.error);
      r.readAsDataURL(blob);
    });
  }
  async function dataUrlToBlob(u) {
    const r = await fetch(u);
    return await r.blob();
  }

  async function bauen(mitMedien) {
    const daten = { app: 'werkstatt', version: VERSION, erstellt: Date.now(), stores: {} };
    for (const s of DB.stores) {
      if (s === 'medien') continue;
      daten.stores[s] = await DB.all(s);
    }
    daten.stores.medien = [];
    if (mitMedien) {
      const medien = await DB.all('medien');
      for (const m of medien) {
        try {
          daten.stores.medien.push({
            id: m.id, typ: m.typ, mime: m.mime, erstellt: m.erstellt,
            dauer: m.dauer || null, data: await blobToDataUrl(m.blob)
          });
        } catch (e) { /* einzelne Datei überspringen */ }
      }
    }
    return daten;
  }

  async function exportieren(mitMedien) {
    Util.toast('Sicherung wird erstellt …');
    const daten = await bauen(mitMedien);
    const blob = new Blob([JSON.stringify(daten)], { type: 'application/json' });
    const name = 'werkstatt-sicherung-' + Util.dateInput() + '.json';
    await DB.setSetting('letztesBackup', Date.now());
    App.teilen(blob, name, 'Werkstatt-Sicherung');
  }

  function importieren() {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = 'application/json,.json';
    inp.style.display = 'none';
    document.body.appendChild(inp);
    inp.onchange = async () => {
      const f = inp.files && inp.files[0];
      inp.remove();
      if (!f) return;
      let daten;
      try { daten = JSON.parse(await f.text()); }
      catch (e) { Util.toast('Datei konnte nicht gelesen werden'); return; }
      if (!daten || daten.app !== 'werkstatt') { Util.toast('Das ist keine Werkstatt-Sicherung'); return; }
      const anz = Object.keys(daten.stores || {}).reduce((s, k) => s + (daten.stores[k] || []).length, 0);
      if (!await Util.confirm('Sicherung vom ' + Util.dateTime(daten.erstellt) + ' mit ' + anz +
        ' Einträgen einspielen? Alles, was jetzt in der App steht, wird ersetzt.', 'Einspielen')) return;
      Util.toast('Wird eingespielt …');
      for (const s of DB.stores) await DB.clear(s);
      for (const s of Object.keys(daten.stores)) {
        if (s === 'medien') continue;
        for (const row of daten.stores[s]) await DB.put(s, row);
      }
      for (const m of (daten.stores.medien || [])) {
        try {
          await DB.put('medien', {
            id: m.id, typ: m.typ, mime: m.mime, erstellt: m.erstellt,
            dauer: m.dauer, blob: await dataUrlToBlob(m.data)
          });
        } catch (e) { /* überspringen */ }
      }
      Util.toast('Fertig – Daten sind zurück');
      App.go('start');
    };
    inp.click();
  }

  async function view() {
    const letztes = await DB.setting('letztesBackup', 0);
    const zahlen = {};
    for (const s of DB.stores) zahlen[s] = (await DB.all(s)).length;
    let platz = '';
    try {
      if (navigator.storage && navigator.storage.estimate) {
        const e = await navigator.storage.estimate();
        platz = (e.usage / 1048576).toFixed(1).replace('.', ',') + ' MB belegt';
      }
    } catch (e) {}

    const html = [
      '<div class="card">',
      '<p style="margin:0 0 6px"><b>Alles liegt auf diesem Handy.</b></p>',
      '<p class="small muted" style="margin:0">Die App braucht kein Internet. Damit bei Handywechsel oder Displaybruch nichts weg ist: ab und zu eine Sicherungsdatei erstellen und z. B. in der Cloud oder auf dem PC ablegen.</p>',
      '</div>',
      '<div class="card tight">',
      '<div class="kv"><span class="k">Letzte Sicherung</span><span class="v">' + (letztes ? Util.dateTime(letztes) : 'noch keine') + '</span></div>',
      '<div class="kv"><span class="k">Material</span><span class="v">' + zahlen.material + '</span></div>',
      '<div class="kv"><span class="k">Werkzeug</span><span class="v">' + zahlen.werkzeug + '</span></div>',
      '<div class="kv"><span class="k">Projekte</span><span class="v">' + zahlen.projekte + '</span></div>',
      '<div class="kv"><span class="k">Orte</span><span class="v">' + zahlen.orte + '</span></div>',
      '<div class="kv"><span class="k">Fotos & Aufnahmen</span><span class="v">' + zahlen.medien + (platz ? ' · ' + platz : '') + '</span></div>',
      '</div>',
      '<div class="stack" style="margin-top:12px">',
      '<button class="btn btn-primary btn-block" id="bExp">Sicherung mit Fotos erstellen</button>',
      '<button class="btn btn-block" id="bExpKlein">Nur Daten sichern (ohne Fotos)</button>',
      '<button class="btn btn-block" id="bImp">Sicherung einspielen</button>',
      '<button class="btn btn-danger btn-block" id="bReset">Alle Daten löschen</button>',
      '</div>'
    ].join('');

    App.paint('Sicherung', html, el => {
      App.showBack('mehr');
      Util.$('#bExp', el).onclick = () => exportieren(true);
      Util.$('#bExpKlein', el).onclick = () => exportieren(false);
      Util.$('#bImp', el).onclick = importieren;
      Util.$('#bReset', el).onclick = async () => {
        if (!await Util.confirm('Wirklich ALLES löschen? Material, Werkzeug, Projekte, Fotos – alles weg.')) return;
        if (!await Util.confirm('Ganz sicher? Das lässt sich nur mit einer Sicherungsdatei rückgängig machen.')) return;
        for (const s of DB.stores) await DB.clear(s);
        Util.toast('Alles gelöscht'); App.go('start');
      };
    });
  }

  return { view, exportieren, importieren };
})();
