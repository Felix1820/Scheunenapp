/* ---------------------------------------------------------------
   einkauf.js – Einkaufsliste: automatisch aus knappem Material
                plus eigene Einträge
----------------------------------------------------------------*/
const Einkauf = (function () {

  async function extras() { return await DB.setting('einkauf_extra', []); }
  async function setExtras(l) { return await DB.setSetting('einkauf_extra', l); }

  async function anzahl() {
    const knapp = await Lager.lowStock();
    const ex = await extras();
    return knapp.length + ex.filter(e => !e.erledigt).length;
  }

  async function view() {
    const knapp = Util.sortBy(await Lager.lowStock(), 'name');
    const ex = await extras();
    const summe = knapp.reduce((s, m) => s + Util.num(m.preis) * Lager.fehlmenge(m), 0);

    const html = [
      knapp.length === 0 && ex.length === 0
        ? '<div class="empty"><span class="big">&#10003;</span>Nichts zu besorgen.<br>Alles über Mindestmenge.</div>' : '',
      knapp.length ? '<h2>Geht zur Neige</h2><div class="list">' + knapp.map(m =>
        '<div class="item" data-mat="' + m.id + '">' +
        '<span class="main"><span class="name">' + Util.esc(m.name) + '</span>' +
        '<span class="sub">noch ' + Util.fmt(m.menge, 2) + ' ' + Util.esc(m.einheit || '') +
        (m.lieferant ? ' · ' + Util.esc(m.lieferant) : '') + '</span></span>' +
        '<span class="right"><span class="badge b-accent">' + Util.fmt(Lager.fehlmenge(m), 2) + ' ' + Util.esc(m.einheit || '') + '</span>' +
        '<button class="btn btn-sm" data-zugang="' + m.id + '">gekauft</button></span>' +
        '</div>').join('') + '</div>' : '',
      summe ? '<p class="small muted right">geschätzte Kosten: ' + Util.eur(summe) + '</p>' : '',
      '<h2>Eigene Einträge</h2>',
      '<div class="card">',
      ex.length ? ex.map(e =>
        '<div class="check"><input type="checkbox" id="e_' + e.id + '" data-ex="' + e.id + '"' + (e.erledigt ? ' checked' : '') + '>' +
        '<label for="e_' + e.id + '" class="grow" style="' + (e.erledigt ? 'text-decoration:line-through;color:var(--muted)' : '') + '">' +
        Util.esc(e.text) + '</label>' +
        '<button class="icon-btn" data-delex="' + e.id + '" style="font-size:18px">&times;</button></div>').join('')
        : '<p class="muted small" style="margin:0 0 10px">Noch nichts notiert.</p>',
      '<div class="row" style="margin-top:8px"><input id="exNeu" class="grow" placeholder="z. B. Schleifpapier K120">',
      '<button class="btn btn-sm btn-primary" id="exAdd">+</button></div>',
      '</div>',
      '<div class="btn-row" style="margin-top:14px"><button class="btn" id="ekTeilen">Liste teilen</button>',
      ex.some(e => e.erledigt) ? '<button class="btn" id="ekClean">Erledigte löschen</button>' : '',
      '</div>'
    ].join('');

    App.paint('Einkaufsliste', html, el => {
      App.showBack('mehr');
      Util.$$('[data-mat]', el).forEach(d => {
        d.onclick = e => { if (!e.target.dataset.zugang) Lager.detail(d.dataset.mat); };
      });
      Util.$$('[data-zugang]', el).forEach(b => {
        b.onclick = async e => { e.stopPropagation(); zugangBuchen(b.dataset.zugang); };
      });
      const add = async () => {
        const inp = Util.$('#exNeu', el);
        const t = inp.value.trim();
        if (!t) return;
        const l = await extras();
        l.push({ id: Util.uid(), text: t, erledigt: false });
        await setExtras(l); view();
      };
      Util.$('#exAdd', el).onclick = add;
      Util.$('#exNeu', el).onkeydown = e => { if (e.key === 'Enter') add(); };
      Util.$$('[data-ex]', el).forEach(cb => {
        cb.onchange = async () => {
          const l = await extras();
          const it = l.find(x => x.id === cb.dataset.ex);
          if (it) it.erledigt = cb.checked;
          await setExtras(l); view();
        };
      });
      Util.$$('[data-delex]', el).forEach(b => {
        b.onclick = async () => {
          await setExtras((await extras()).filter(x => x.id !== b.dataset.delex));
          view();
        };
      });
      const clean = Util.$('#ekClean', el);
      if (clean) clean.onclick = async () => {
        await setExtras((await extras()).filter(x => !x.erledigt));
        Util.toast('Aufgeräumt'); view();
      };
      Util.$('#ekTeilen', el).onclick = async () => {
        const zeilen = knapp.map(m => '- ' + m.name + ': ' + Util.fmt(Lager.fehlmenge(m), 2) + ' ' + (m.einheit || ''))
          .concat((await extras()).filter(e => !e.erledigt).map(e => '- ' + e.text));
        if (!zeilen.length) { Util.toast('Die Liste ist leer'); return; }
        const text = 'Einkaufsliste Werkstatt (' + Util.date(Date.now()) + ')\n' + zeilen.join('\n');
        if (navigator.share) { navigator.share({ title: 'Einkaufsliste', text: text }).catch(() => {}); }
        else { App.teilen(new Blob([text], { type: 'text/plain' }), 'einkaufsliste.txt', 'Einkaufsliste'); }
      };
    });
  }

  async function zugangBuchen(materialId) {
    const m = await DB.get('material', materialId);
    if (!m) return;
    Util.sheet('Zugang: ' + m.name, [
      '<p class="muted small">Bestand jetzt: ' + Util.fmt(m.menge, 2) + ' ' + Util.esc(m.einheit || '') + '</p>',
      '<div class="field"><label>Gekaufte Menge (' + Util.esc(m.einheit || '') + ')</label>',
      '<input name="menge" type="text" inputmode="decimal" value="' + Util.fmt(Lager.fehlmenge(m), 2) + '" id="zgInp"></div>',
      '<div class="field"><label>Preis je Einheit (€) – optional aktualisieren</label>',
      '<input name="preis" type="text" inputmode="decimal" value="' + (Util.num(m.preis) ? Util.fmt(m.preis, 2) : '') + '"></div>',
      '<div class="btn-row"><button class="btn" id="zgAb">Abbrechen</button>',
      '<button class="btn btn-primary" id="zgOk">Einbuchen</button></div>'
    ].join(''), el => {
      const i = Util.$('#zgInp', el); i.focus(); i.select();
      Util.$('#zgAb', el).onclick = Util.closeSheet;
      Util.$('#zgOk', el).onclick = async () => {
        const d = Util.formData(el);
        m.menge = Util.num(m.menge) + Util.num(d.menge);
        if (d.preis !== '') m.preis = Util.num(d.preis);
        await DB.save('material', m);
        Util.closeSheet(); Util.toast('Eingebucht'); view();
      };
    });
  }

  return { view, anzahl, zugangBuchen };
})();
