/* ---------------------------------------------------------------
   rechner.js – Werkzeugkasten: Zuschnitt, Bedarf, Maße, Tabellen
----------------------------------------------------------------*/
const Rechner = (function () {
  let sub = null;
  let zuschnittTeile = [{ laenge: '', anzahl: '1' }];

  const MENU = [
    ['zuschnitt', '&#9986;', 'Zuschnitt-Optimierer', 'Bretter und Latten optimal aufteilen – mit Sägeblattbreite'],
    ['bedarf', '&#9632;', 'Materialbedarf', 'Farbe, Dielen, Fliesen, Beton aus Maßen ausrechnen'],
    ['masse', '&#8644;', 'Maße umrechnen', 'mm, cm, m, Zoll, Fuß – hin und her'],
    ['bohren', '&#9673;', 'Bohrer & Schrauben', 'Vorbohren, Dübel, Gewinde – Tabelle'],
    ['winkel', '&#9651;', 'Diagonale & Winkel', 'Rechteck prüfen, Diagonale, fehlende Seite']
  ];

  function view(which) {
    sub = which || null;
    if (!sub) return menu();
    if (sub === 'zuschnitt') return zuschnitt();
    if (sub === 'bedarf') return bedarf();
    if (sub === 'masse') return masse();
    if (sub === 'bohren') return bohren();
    if (sub === 'winkel') return winkel();
    return menu();
  }

  function menu() {
    const html = '<div class="list">' + MENU.map(m =>
      '<button class="item" data-sub="' + m[0] + '"><span class="avatar">' + m[1] + '</span>' +
      '<span class="main"><span class="name">' + m[2] + '</span><span class="sub">' + m[3] + '</span></span>' +
      '<span class="muted">&#8250;</span></button>').join('') + '</div>';
    App.paint('Rechner', html, el => {
      App.showBack('mehr');
      Util.$$('.item', el).forEach(b => { b.onclick = () => view(b.dataset.sub); });
    });
  }

  /* ================= Zuschnitt ================= */
  function zuschnitt() {
    const rows = zuschnittTeile.map((t, i) =>
      '<div class="row" style="margin-bottom:8px">' +
      '<input class="grow zLaenge" type="text" inputmode="decimal" placeholder="Länge mm" value="' + Util.esc(t.laenge) + '" data-i="' + i + '">' +
      '<input style="width:78px" class="zAnzahl" type="text" inputmode="numeric" placeholder="Stk" value="' + Util.esc(t.anzahl) + '" data-i="' + i + '">' +
      '<button class="icon-btn" data-del="' + i + '">&times;</button></div>').join('');

    const html = [
      '<div class="card">',
      '<div class="fields2">',
      '<div class="field"><label>Rohlänge (mm)</label><input id="zRoh" type="text" inputmode="decimal" value="' + (localStorage.getItem('zRoh') || '2000') + '"></div>',
      '<div class="field"><label>Sägeblatt (mm)</label><input id="zKerf" type="text" inputmode="decimal" value="' + (localStorage.getItem('zKerf') || '3') + '"></div>',
      '</div>',
      '<label>Benötigte Stücke</label>', rows,
      '<button class="btn btn-sm btn-block" id="zAdd">+ Zeile</button>',
      '<button class="btn btn-primary btn-block" id="zGo" style="margin-top:10px">Zuschnitt berechnen</button>',
      '</div>',
      '<div id="zErgebnis"></div>'
    ].join('');

    App.paint('Zuschnitt-Optimierer', html, el => {
      App.showBack('rechner');
      const sammeln = () => {
        zuschnittTeile = Util.$$('.zLaenge', el).map((inp, i) => ({
          laenge: inp.value, anzahl: Util.$$('.zAnzahl', el)[i].value
        }));
      };
      Util.$$('.zLaenge,.zAnzahl', el).forEach(i => { i.onchange = sammeln; });
      Util.$('#zAdd', el).onclick = () => { sammeln(); zuschnittTeile.push({ laenge: '', anzahl: '1' }); zuschnitt(); };
      Util.$$('[data-del]', el).forEach(b => {
        b.onclick = () => {
          sammeln();
          zuschnittTeile.splice(+b.dataset.del, 1);
          if (!zuschnittTeile.length) zuschnittTeile = [{ laenge: '', anzahl: '1' }];
          zuschnitt();
        };
      });
      Util.$('#zGo', el).onclick = () => {
        sammeln();
        const roh = Util.num(Util.$('#zRoh', el).value);
        const kerf = Util.num(Util.$('#zKerf', el).value);
        localStorage.setItem('zRoh', roh); localStorage.setItem('zKerf', kerf);
        if (roh <= 0) { Util.toast('Rohlänge eintragen'); return; }
        const stuecke = [];
        zuschnittTeile.forEach(t => {
          const l = Util.num(t.laenge), n = Math.round(Util.num(t.anzahl) || 0);
          for (let i = 0; i < n; i++) if (l > 0) stuecke.push(l);
        });
        if (!stuecke.length) { Util.toast('Mindestens ein Stück eintragen'); return; }
        Util.$('#zErgebnis', el).innerHTML = planHtml(rechneZuschnitt(roh, kerf, stuecke), roh);
      };
    });
  }

  function rechneZuschnitt(roh, kerf, stuecke) {
    const zuLang = stuecke.filter(s => s > roh);
    const ok = stuecke.filter(s => s <= roh).sort((a, b) => b - a);
    const stangen = [];
    ok.forEach(s => {
      let platz = null;
      for (const st of stangen) {
        const brauch = s + (st.cuts.length ? kerf : 0);
        if (st.rest >= brauch - 0.001) { st.rest -= brauch; st.cuts.push(s); platz = st; break; }
      }
      if (!platz) stangen.push({ rest: roh - s, cuts: [s] });
    });
    const verschnitt = stangen.reduce((a, s) => a + s.rest, 0);
    const genutzt = ok.reduce((a, s) => a + s, 0);
    return { stangen: stangen, zuLang: zuLang, verschnitt: verschnitt, genutzt: genutzt,
             gesamt: stangen.length * roh };
  }

  function planHtml(r, roh) {
    if (!r.stangen.length && !r.zuLang.length) return '';
    const quote = r.gesamt ? (r.genutzt / r.gesamt) * 100 : 0;
    return [
      '<div class="card">',
      '<div class="between"><b>' + r.stangen.length + ' × Rohling à ' + Util.fmt(roh, 0) + ' mm</b>',
      '<span class="badge b-accent">' + Util.fmt(quote, 0) + '% genutzt</span></div>',
      '<div class="bar"><i style="width:' + quote + '%;background:var(--accent)"></i></div>',
      '<p class="small muted" style="margin:8px 0 0">Verschnitt gesamt: ' + Util.fmt(r.verschnitt, 0) + ' mm</p>',
      '</div>',
      r.stangen.map((s, i) => [
        '<div class="card tight">',
        '<div class="between"><b>Rohling ' + (i + 1) + '</b><span class="muted small">Rest ' + Util.fmt(s.rest, 0) + ' mm</span></div>',
        '<div class="row wrap" style="gap:6px;margin-top:6px">' +
        s.cuts.map(c => '<span class="badge b-grey">' + Util.fmt(c, 0) + '</span>').join('') + '</div>',
        '</div>'
      ].join('')).join(''),
      r.zuLang.length ? '<div class="card"><p style="margin:0;color:var(--danger)">' + r.zuLang.length +
        ' Stück passen nicht auf die Rohlänge (' + r.zuLang.map(x => Util.fmt(x, 0)).join(', ') + ' mm)</p></div>' : ''
    ].join('');
  }

  /* ================= Materialbedarf ================= */
  function bedarf() {
    const html = [
      '<div class="chips" id="bArt">',
      '<button class="chip on" data-a="farbe">Farbe / Lack</button>',
      '<button class="chip" data-a="dielen">Bretter / Dielen</button>',
      '<button class="chip" data-a="fliesen">Fliesen / Platten</button>',
      '<button class="chip" data-a="beton">Beton / Schüttgut</button>',
      '</div><div id="bBody"></div>'
    ].join('');
    App.paint('Materialbedarf', html, el => {
      App.showBack('rechner');
      const zeige = a => {
        Util.$$('#bArt .chip', el).forEach(c => c.classList.toggle('on', c.dataset.a === a));
        Util.$('#bBody', el).innerHTML = bedarfForm(a);
        const go = Util.$('#bGo', el);
        go.onclick = () => {
          const d = Util.formData(Util.$('#bBody', el));
          Util.$('#bOut', el).innerHTML = bedarfRechnen(a, d);
        };
      };
      Util.$$('#bArt .chip', el).forEach(c => { c.onclick = () => zeige(c.dataset.a); });
      zeige('farbe');
    });
  }

  function feld(label, name, val, unit) {
    return '<div class="field"><label>' + label + (unit ? ' (' + unit + ')' : '') + '</label>' +
      '<input name="' + name + '" type="text" inputmode="decimal" value="' + (val === undefined ? '' : val) + '"></div>';
  }

  function bedarfForm(a) {
    let fields = '';
    if (a === 'farbe') {
      fields = '<div class="fields2">' + feld('Länge', 'l', '', 'm') + feld('Höhe / Breite', 'b', '', 'm') + '</div>' +
        '<div class="fields2">' + feld('Verbrauch', 'v', '120', 'ml/m²') + feld('Anstriche', 'n', '2') + '</div>' +
        feld('Abzug Fenster/Türen', 'abzug', '0', 'm²');
    } else if (a === 'dielen') {
      fields = '<div class="fields2">' + feld('Fläche Länge', 'l', '', 'm') + feld('Fläche Breite', 'b', '', 'm') + '</div>' +
        '<div class="fields2">' + feld('Diele Länge', 'dl', '2', 'm') + feld('Diele Breite', 'db', '0,14', 'm') + '</div>' +
        feld('Verschnitt', 'vs', '10', '%');
    } else if (a === 'fliesen') {
      fields = '<div class="fields2">' + feld('Fläche Länge', 'l', '', 'm') + feld('Fläche Breite', 'b', '', 'm') + '</div>' +
        '<div class="fields2">' + feld('Fliese Länge', 'fl', '30', 'cm') + feld('Fliese Breite', 'fb', '30', 'cm') + '</div>' +
        '<div class="fields2">' + feld('Fuge', 'fuge', '3', 'mm') + feld('Verschnitt', 'vs', '10', '%') + '</div>';
    } else {
      fields = '<div class="fields3">' + feld('Länge', 'l', '', 'm') + feld('Breite', 'b', '', 'm') + feld('Höhe', 'h', '', 'm') + '</div>' +
        '<div class="fields2">' + feld('Sackgröße', 'sack', '25', 'kg') + feld('Dichte', 'dichte', '2,1', 'kg/l') + '</div>';
    }
    return '<div class="card">' + fields + '<button class="btn btn-primary btn-block" id="bGo">Ausrechnen</button></div><div id="bOut"></div>';
  }

  function ergebnisCard(zeilen) {
    return '<div class="card">' + zeilen.map(z =>
      '<div class="kv"><span class="k">' + z[0] + '</span><span class="v"' +
      (z[2] ? ' style="color:var(--accent);font-size:17px"' : '') + '>' + z[1] + '</span></div>').join('') + '</div>';
  }

  function bedarfRechnen(a, d) {
    const n = Util.num;
    if (a === 'farbe') {
      const flaeche = Math.max(0, n(d.l) * n(d.b) - n(d.abzug));
      const liter = flaeche * (n(d.v) / 1000) * (n(d.n) || 1);
      return ergebnisCard([
        ['Fläche', Util.fmt(flaeche, 2) + ' m²'],
        ['Anstriche', Util.fmt(d.n, 0)],
        ['Farbbedarf', Util.fmt(liter, 2) + ' l', true],
        ['Gebinde 2,5 l', Math.ceil(liter / 2.5) + ' Stück'],
        ['Gebinde 5 l', Math.ceil(liter / 5) + ' Stück']
      ]);
    }
    if (a === 'dielen') {
      const flaeche = n(d.l) * n(d.b);
      const proDiele = n(d.dl) * n(d.db);
      if (proDiele <= 0) return ergebnisCard([['Dielenmaß fehlt', '–']]);
      const stk = Math.ceil((flaeche / proDiele) * (1 + n(d.vs) / 100));
      return ergebnisCard([
        ['Fläche', Util.fmt(flaeche, 2) + ' m²'],
        ['Fläche je Diele', Util.fmt(proDiele, 3) + ' m²'],
        ['mit ' + Util.fmt(d.vs, 0) + '% Verschnitt', Util.fmt(flaeche * (1 + n(d.vs) / 100), 2) + ' m²'],
        ['Dielen', stk + ' Stück', true],
        ['Laufende Meter', Util.fmt(stk * n(d.dl), 1) + ' lfm']
      ]);
    }
    if (a === 'fliesen') {
      const flaeche = n(d.l) * n(d.b);
      const fl = (n(d.fl) + n(d.fuge) / 10) / 100;
      const fb = (n(d.fb) + n(d.fuge) / 10) / 100;
      const pro = fl * fb;
      if (pro <= 0) return ergebnisCard([['Fliesenmaß fehlt', '–']]);
      const stk = Math.ceil((flaeche / pro) * (1 + n(d.vs) / 100));
      return ergebnisCard([
        ['Fläche', Util.fmt(flaeche, 2) + ' m²'],
        ['Fliesen je m²', Util.fmt(1 / pro, 1)],
        ['Fliesen', stk + ' Stück', true],
        ['Reserve enthalten', Util.fmt(d.vs, 0) + ' %']
      ]);
    }
    const volM3 = n(d.l) * n(d.b) * n(d.h);
    const liter = volM3 * 1000;
    const kg = liter * n(d.dichte);
    const saecke = n(d.sack) > 0 ? Math.ceil(kg / n(d.sack)) : 0;
    return ergebnisCard([
      ['Volumen', Util.fmt(volM3, 3) + ' m³'],
      ['in Liter', Util.fmt(liter, 0) + ' l'],
      ['Gewicht', Util.fmt(kg, 0) + ' kg'],
      ['Säcke à ' + Util.fmt(d.sack, 0) + ' kg', saecke + ' Stück', true]
    ]);
  }

  /* ================= Maße umrechnen ================= */
  function masse() {
    const html = [
      '<div class="card">',
      '<div class="row"><input id="mVal" class="grow" type="text" inputmode="decimal" placeholder="Wert" value="100">',
      '<select id="mUnit" style="width:110px">',
      ['mm', 'cm', 'm', 'Zoll', 'Fuß'].map(u => '<option' + (u === 'mm' ? ' selected' : '') + '>' + u + '</option>').join(''),
      '</select></div>',
      '</div><div id="mOut"></div>',
      '<div class="card"><p class="small muted" style="margin:0 0 8px">Zoll in Brüchen</p><div id="mZoll" class="small"></div></div>'
    ].join('');
    App.paint('Maße umrechnen', html, el => {
      App.showBack('rechner');
      const rechne = () => {
        const v = Util.num(Util.$('#mVal', el).value);
        const u = Util.$('#mUnit', el).value;
        const mm = u === 'mm' ? v : u === 'cm' ? v * 10 : u === 'm' ? v * 1000 : u === 'Zoll' ? v * 25.4 : v * 304.8;
        Util.$('#mOut', el).innerHTML = ergebnisCard([
          ['Millimeter', Util.fmt(mm, 2) + ' mm'],
          ['Zentimeter', Util.fmt(mm / 10, 3) + ' cm'],
          ['Meter', Util.fmt(mm / 1000, 4) + ' m'],
          ['Zoll', Util.fmt(mm / 25.4, 3) + ' "', true],
          ['Fuß', Util.fmt(mm / 304.8, 3) + ' ft']
        ]);
        Util.$('#mZoll', el).innerHTML = zollBruch(mm / 25.4);
      };
      Util.$('#mVal', el).oninput = rechne;
      Util.$('#mUnit', el).onchange = rechne;
      rechne();
    });
  }

  function zollBruch(zoll) {
    const ganz = Math.floor(zoll);
    const rest = zoll - ganz;
    const nenner = 16;
    let z = Math.round(rest * nenner);
    let n = nenner;
    if (z === 0) return (ganz || 0) + ' Zoll (genau)';
    while (z % 2 === 0 && n % 2 === 0) { z /= 2; n /= 2; }
    return (ganz ? ganz + ' ' : '') + z + '/' + n + ' Zoll &nbsp;<span class="muted">(gerundet auf 1/16")</span>';
  }

  /* ================= Bohrer & Schrauben ================= */
  function bohren() {
    const schrauben = [[3, 1.5, 2.0], [3.5, 1.8, 2.2], [4, 2.0, 2.5], [4.5, 2.5, 3.0],
      [5, 3.0, 3.5], [6, 3.5, 4.0], [8, 5.0, 5.5]];
    const gewinde = [['M3', 2.5, 3.4], ['M4', 3.3, 4.5], ['M5', 4.2, 5.5], ['M6', 5.0, 6.6],
      ['M8', 6.8, 9.0], ['M10', 8.5, 11.0], ['M12', 10.2, 13.5]];
    const html = [
      '<h2>Holzschrauben vorbohren</h2>',
      '<div class="card tight"><div class="kv"><span class="k"><b>Schraube</b></span><span class="v"><b>Weichholz / Hartholz</b></span></div>',
      schrauben.map(s => '<div class="kv"><span class="k">Ø ' + Util.fmt(s[0], 1) + ' mm</span>' +
        '<span class="v">' + Util.fmt(s[1], 1) + ' mm &nbsp;/&nbsp; ' + Util.fmt(s[2], 1) + ' mm</span></div>').join(''),
      '</div>',
      '<p class="small muted">Faustregel: Kerndurchmesser der Schraube = Bohrer. Hartholz ca. 0,7 × Schraubendurchmesser, Weichholz ca. 0,6 ×. Bei Hirnholz und nah an der Kante immer vorbohren.</p>',
      '<h2>Dübel</h2>',
      '<div class="card tight">' + [[5, 5, 30], [6, 6, 40], [8, 8, 50], [10, 10, 60], [12, 12, 70]].map(d =>
        '<div class="kv"><span class="k">Dübel Ø ' + d[0] + ' mm</span><span class="v">Bohrer ' + d[1] + ' mm · Tiefe ≥ ' + d[2] + ' mm</span></div>').join('') + '</div>',
      '<h2>Metrisches Gewinde</h2>',
      '<div class="card tight"><div class="kv"><span class="k"><b>Größe</b></span><span class="v"><b>Kernloch / Durchgang</b></span></div>',
      gewinde.map(g => '<div class="kv"><span class="k">' + g[0] + '</span><span class="v">' +
        Util.fmt(g[1], 1) + ' mm &nbsp;/&nbsp; ' + Util.fmt(g[2], 1) + ' mm</span></div>').join(''),
      '</div>',
      '<h2>Eigene Schraube</h2>',
      '<div class="card">',
      '<div class="fields2">',
      '<div class="field"><label>Schrauben-Ø (mm)</label><input id="sD" type="text" inputmode="decimal" value="5"></div>',
      '<div class="field"><label>Holz</label><select id="sH"><option value="0.6">Weichholz</option><option value="0.7">Hartholz</option></select></div>',
      '</div><div id="sOut"></div></div>'
    ].join('');
    App.paint('Bohrer & Schrauben', html, el => {
      App.showBack('rechner');
      const rechne = () => {
        const d = Util.num(Util.$('#sD', el).value), f = parseFloat(Util.$('#sH', el).value);
        Util.$('#sOut', el).innerHTML = ergebnisCard([
          ['Vorbohren', Util.fmt(d * f, 1) + ' mm', true],
          ['Durchgangsloch', Util.fmt(d + 0.5, 1) + ' mm'],
          ['Senker', Util.fmt(d * 2, 1) + ' mm']
        ]);
      };
      Util.$('#sD', el).oninput = rechne;
      Util.$('#sH', el).onchange = rechne;
      rechne();
    });
  }

  /* ================= Diagonale & Winkel ================= */
  function winkel() {
    const html = [
      '<div class="card">',
      '<p class="small muted">Rechteck prüfen: beide Diagonalen messen. Sind sie gleich lang, ist es rechtwinklig.</p>',
      '<div class="fields2">',
      '<div class="field"><label>Seite a (mm)</label><input id="wA" type="text" inputmode="decimal" value="1000"></div>',
      '<div class="field"><label>Seite b (mm)</label><input id="wB" type="text" inputmode="decimal" value="600"></div>',
      '</div><div id="wOut"></div></div>',
      '<div class="card">',
      '<p class="small muted">Fehlende Seite im rechtwinkligen Dreieck (c = längste Seite)</p>',
      '<div class="fields2">',
      '<div class="field"><label>Kathete a (mm)</label><input id="kA" type="text" inputmode="decimal" value="300"></div>',
      '<div class="field"><label>Hypotenuse c (mm)</label><input id="kC" type="text" inputmode="decimal" value="500"></div>',
      '</div><div id="kOut"></div></div>',
      '<div class="card"><p class="small muted" style="margin:0">Baustellen-Trick 3-4-5: 60 cm an der einen Kante, 80 cm an der anderen – wenn die Verbindung genau 100 cm misst, stimmt der rechte Winkel.</p></div>'
    ].join('');
    App.paint('Diagonale & Winkel', html, el => {
      App.showBack('rechner');
      const r1 = () => {
        const a = Util.num(Util.$('#wA', el).value), b = Util.num(Util.$('#wB', el).value);
        const diag = Math.sqrt(a * a + b * b);
        Util.$('#wOut', el).innerHTML = ergebnisCard([
          ['Diagonale', Util.fmt(diag, 1) + ' mm', true],
          ['Fläche', Util.fmt((a / 1000) * (b / 1000), 3) + ' m²'],
          ['Umfang', Util.fmt(2 * (a + b) / 1000, 3) + ' m'],
          ['Winkel zur Seite a', Util.fmt(Math.atan2(b, a) * 180 / Math.PI, 1) + ' °']
        ]);
      };
      const r2 = () => {
        const a = Util.num(Util.$('#kA', el).value), c = Util.num(Util.$('#kC', el).value);
        const ok = c > a;
        Util.$('#kOut', el).innerHTML = ergebnisCard([
          ['Kathete b', ok ? Util.fmt(Math.sqrt(c * c - a * a), 1) + ' mm' : 'c muss größer sein als a', true],
          ['Winkel bei a', ok ? Util.fmt(Math.acos(a / c) * 180 / Math.PI, 1) + ' °' : '–']
        ]);
      };
      ['#wA', '#wB'].forEach(s => { Util.$(s, el).oninput = r1; });
      ['#kA', '#kC'].forEach(s => { Util.$(s, el).oninput = r2; });
      r1(); r2();
    });
  }

  return { view, rechneZuschnitt };
})();
