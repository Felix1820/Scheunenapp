/* ---------------------------------------------------------------
   etiketten.js – QR-Etiketten für Regale, Kisten, Material, Werkzeug
----------------------------------------------------------------*/
const Etiketten = (function () {
  const PREFIX = 'WST';

  function payload(typ, id) { return PREFIX + ':' + typ + ':' + id; }

  function parse(text) {
    if (!text) return null;
    const p = String(text).split(':');
    if (p[0] !== PREFIX || p.length < 3) return null;
    return { typ: p[1], id: p.slice(2).join(':') };
  }

  function svg(text, cell) {
    const qr = qrcode(0, 'M');
    qr.addData(text);
    qr.make();
    return qr.createSvgTag({ cellSize: cell || 4, margin: 2 });
  }

  /* ---------- Übersicht ---------- */
  async function view() {
    const orte = Util.sortBy(await DB.all('orte'), 'name');
    const material = await DB.all('material');
    const werkzeug = await DB.all('werkzeug');

    const html = [
      '<p class="muted small">QR-Code auf Regal, Kiste oder Werkzeug kleben. Einmal scannen – und die App zeigt sofort, was drin ist oder wie der Bestand steht.</p>',
      '<h2>Orte</h2>',
      orte.length ? '<div class="list">' + orte.map(o =>
        '<button class="item" data-ort="' + o.id + '"><span class="avatar">&#9635;</span>' +
        '<span class="main"><span class="name">' + Util.esc(o.name) + '</span>' +
        '<span class="sub">' + Util.esc(o.typ || 'Ort') + '</span></span>' +
        '<span class="badge b-grey">QR</span></button>').join('') + '</div>'
        : '<p class="muted small">Noch keine Orte angelegt.</p>',
      '<button class="btn btn-sm btn-block" id="ortAdd" style="margin-top:8px">+ Ort anlegen</button>',
      '<h2>Etiketten drucken</h2>',
      '<div class="card stack">',
      '<div class="check"><input type="checkbox" id="chkOrte" checked><label for="chkOrte">Orte (' + orte.length + ')</label></div>',
      '<div class="check"><input type="checkbox" id="chkMat"><label for="chkMat">Material (' + material.length + ')</label></div>',
      '<div class="check"><input type="checkbox" id="chkWz"><label for="chkWz">Werkzeug (' + werkzeug.length + ')</label></div>',
      '<button class="btn btn-primary btn-block" id="etGo">Etiketten erzeugen</button>',
      '</div>',
      '<div id="etOut"></div>'
    ].join('');

    App.paint('QR-Etiketten', html, el => {
      App.showBack('mehr');
      Util.$('#ortAdd', el).onclick = () => ortForm();
      Util.$$('[data-ort]', el).forEach(b => { b.onclick = () => ortDetail(b.dataset.ort); });
      Util.$('#etGo', el).onclick = async () => {
        const items = [];
        if (Util.$('#chkOrte', el).checked) orte.forEach(o => items.push({ typ: 'ort', id: o.id, name: o.name, sub: o.typ || 'Ort' }));
        if (Util.$('#chkMat', el).checked) Util.sortBy(material, 'name').forEach(m => items.push({ typ: 'material', id: m.id, name: m.name, sub: m.ort || 'Material' }));
        if (Util.$('#chkWz', el).checked) Util.sortBy(werkzeug, 'name').forEach(w => items.push({ typ: 'werkzeug', id: w.id, name: w.name, sub: w.ort || 'Werkzeug' }));
        if (!items.length) { Util.toast('Nichts ausgewählt'); return; }
        Util.$('#etOut', el).innerHTML = [
          '<h2>' + items.length + ' Etiketten</h2>',
          '<div class="labels">' + items.map(i =>
            '<div class="label-card">' + svg(payload(i.typ, i.id), 4) +
            '<div class="lname">' + Util.esc(i.name) + '</div>' +
            '<div class="lsub">' + Util.esc(i.sub) + '</div></div>').join('') + '</div>',
          '<div class="btn-row no-print" style="margin-top:12px">',
          '<button class="btn btn-primary" id="etBild">Als Bild teilen</button>',
          App.isNative() ? '' : '<button class="btn" id="etDruck">Drucken</button>',
          '</div>',
          App.isNative() ? '<p class="small muted no-print">Zum Ausdrucken das Bild teilen – z. B. an den PC schicken oder in der Cloud ablegen.</p>' : ''
        ].join('');
        Util.$('#etBild', el).onclick = () => alsBild(items);
        const dr = Util.$('#etDruck', el);
        if (dr) dr.onclick = () => { try { window.print(); } catch (e) { Util.toast('Drucken hier nicht möglich – nimm „Als Bild teilen“'); } };
      };
    });
  }

  /* ---------- Einzel-Etikett ---------- */
  function single(typ, id, name) {
    Util.sheet('Etikett: ' + name, [
      '<div class="label-card" style="max-width:220px;margin:0 auto">' + svg(payload(typ, id), 5) +
      '<div class="lname">' + Util.esc(name) + '</div></div>',
      '<div class="btn-row" style="margin-top:14px"><button class="btn" id="e1Bild">Als Bild teilen</button>',
      '<button class="btn btn-primary" id="e1Zu">Fertig</button></div>'
    ].join(''), el => {
      Util.$('#e1Zu', el).onclick = Util.closeSheet;
      Util.$('#e1Bild', el).onclick = () => alsBild([{ typ: typ, id: id, name: name, sub: '' }]);
    });
  }

  /* ---------- Etiketten als PNG ---------- */
  function alsBild(items) {
    const cols = items.length === 1 ? 1 : 3;
    const cw = 400, ch = 470, pad = 24;
    const rows = Math.ceil(items.length / cols);
    const c = document.createElement('canvas');
    c.width = cols * cw + pad * 2;
    c.height = rows * ch + pad * 2;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);

    items.forEach((it, i) => {
      const x = pad + (i % cols) * cw, y = pad + Math.floor(i / cols) * ch;
      const qr = qrcode(0, 'M');
      qr.addData(payload(it.typ, it.id));
      qr.make();
      const n = qr.getModuleCount();
      const size = 330;
      const cell = size / n;
      const ox = x + (cw - size) / 2, oy = y + 20;
      ctx.fillStyle = '#000';
      for (let r = 0; r < n; r++) {
        for (let col = 0; col < n; col++) {
          if (qr.isDark(r, col)) ctx.fillRect(ox + col * cell, oy + r * cell, Math.ceil(cell), Math.ceil(cell));
        }
      }
      ctx.fillStyle = '#000';
      ctx.font = 'bold 26px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(kuerzen(ctx, it.name, cw - 24), x + cw / 2, oy + size + 34);
      if (it.sub) {
        ctx.fillStyle = '#555';
        ctx.font = '20px sans-serif';
        ctx.fillText(kuerzen(ctx, it.sub, cw - 24), x + cw / 2, oy + size + 62);
      }
      ctx.strokeStyle = '#ccc';
      ctx.setLineDash([6, 6]);
      ctx.strokeRect(x + 6, y + 6, cw - 12, ch - 12);
      ctx.setLineDash([]);
    });

    c.toBlob(b => {
      App.teilen(b, 'werkstatt-etiketten.png', 'QR-Etiketten');
    }, 'image/png');
  }

  function kuerzen(ctx, text, max) {
    let t = String(text);
    while (ctx.measureText(t).width > max && t.length > 4) t = t.slice(0, -2);
    return t === String(text) ? t : t + '…';
  }

  /* ---------- Orte ---------- */
  async function ortForm(id) {
    const o = id ? await DB.get('orte', id) : { name: '', typ: 'Regal', notiz: '' };
    Util.sheet(id ? 'Ort bearbeiten' : 'Neuer Ort', [
      '<div class="field"><label>Name</label><input name="name" value="' + Util.esc(o.name) + '" placeholder="z. B. Regal B"></div>',
      '<div class="field"><label>Art</label><select name="typ">' +
        ['Regal', 'Kiste', 'Schrank', 'Schublade', 'Wand', 'Anhänger', 'Sonstiges']
          .map(t => '<option' + (o.typ === t ? ' selected' : '') + '>' + t + '</option>').join('') + '</select></div>',
      '<div class="field"><label>Notiz</label><input name="notiz" value="' + Util.esc(o.notiz || '') + '"></div>',
      '<div class="btn-row"><button class="btn" id="oAb">Abbrechen</button>',
      '<button class="btn btn-primary" id="oOk">Speichern</button></div>'
    ].join(''), el => {
      Util.$('#oAb', el).onclick = Util.closeSheet;
      Util.$('#oOk', el).onclick = async () => {
        const d = Util.formData(el);
        if (!d.name.trim()) { Util.toast('Bitte einen Namen eintragen'); return; }
        Object.assign(o, { name: d.name.trim(), typ: d.typ, notiz: d.notiz.trim() });
        await DB.save('orte', o);
        Util.closeSheet(); Util.toast('Gespeichert'); view();
      };
    });
  }

  /* Was liegt an diesem Ort? */
  async function ortDetail(id) {
    const o = await DB.get('orte', id);
    if (!o) return;
    const mat = (await DB.all('material')).filter(m => (m.ort || '').toLowerCase() === o.name.toLowerCase());
    const wz = (await DB.all('werkzeug')).filter(w => (w.ort || '').toLowerCase() === o.name.toLowerCase());
    Util.sheet(o.name, [
      '<div class="label-card" style="max-width:170px;margin:0 auto 14px">' + svg(payload('ort', o.id), 4) + '</div>',
      '<h3>Material hier (' + mat.length + ')</h3>',
      mat.length ? '<div class="list">' + mat.map(m =>
        '<button class="item" data-mat="' + m.id + '"><span class="main"><span class="name">' + Util.esc(m.name) + '</span>' +
        '<span class="sub">' + Util.fmt(m.menge, 2) + ' ' + Util.esc(m.einheit || '') + '</span></span>' +
        (Lager.istKnapp(m) ? '<span class="badge b-danger">knapp</span>' : '') + '</button>').join('') + '</div>'
        : '<p class="muted small">nichts</p>',
      '<h3 style="margin-top:14px">Werkzeug hier (' + wz.length + ')</h3>',
      wz.length ? '<div class="list">' + wz.map(w =>
        '<button class="item" data-wz="' + w.id + '"><span class="main"><span class="name">' + Util.esc(w.name) + '</span>' +
        '<span class="sub">' + (w.verliehenAn ? 'verliehen an ' + Util.esc(w.verliehenAn) : Werkzeug.ZUSTAND[w.zustand || 'ok'].label) + '</span></span></button>').join('') + '</div>'
        : '<p class="muted small">nichts</p>',
      '<div class="btn-row" style="margin-top:14px"><button class="btn" id="oEdit">Bearbeiten</button>',
      '<button class="btn" id="oEt">Etikett teilen</button></div>',
      '<button class="btn btn-danger btn-block" id="oDel" style="margin-top:8px">Ort löschen</button>'
    ].join(''), el => {
      Util.$$('[data-mat]', el).forEach(b => { b.onclick = () => Lager.detail(b.dataset.mat); });
      Util.$$('[data-wz]', el).forEach(b => { b.onclick = () => Werkzeug.detail(b.dataset.wz); });
      Util.$('#oEdit', el).onclick = () => ortForm(o.id);
      Util.$('#oEt', el).onclick = () => alsBild([{ typ: 'ort', id: o.id, name: o.name, sub: o.typ || '' }]);
      Util.$('#oDel', el).onclick = async () => {
        if (await Util.confirm('Ort „' + o.name + '“ löschen? Material und Werkzeug bleiben erhalten.')) {
          await DB.del('orte', o.id);
          Util.closeSheet(); view();
        }
      };
    });
  }

  return { view, single, payload, parse, svg, ortDetail, ortForm, alsBild };
})();
