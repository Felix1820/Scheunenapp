/* ---------------------------------------------------------------
   projekte.js – Projekte: Schritte, Zeit, Material, Fotos, Notizen
----------------------------------------------------------------*/
const Projekte = (function () {
  let filter = 'aktiv';
  let tickTimer = null;

  const STATUS = {
    offen:   { label: 'Offen',   cls: 'b-grey' },
    laufend: { label: 'Läuft',   cls: 'b-accent' },
    fertig:  { label: 'Fertig',  cls: 'b-ok' }
  };

  /* ---------- laufender Timer (global, nur einer) ---------- */
  async function running() { return await DB.setting('timer', null); }

  async function startTimer(projektId) {
    const cur = await running();
    if (cur && cur.projektId !== projektId) {
      const p = await DB.get('projekte', cur.projektId);
      await stopTimer();
      Util.toast('Timer von „' + (p ? p.name : '?') + '“ gestoppt');
    }
    await DB.setSetting('timer', { projektId: projektId, start: Date.now() });
    const p = await DB.get('projekte', projektId);
    if (p && p.status !== 'fertig') { p.status = 'laufend'; await DB.save('projekte', p); }
    if (navigator.vibrate) navigator.vibrate(20);
  }

  async function stopTimer(notiz) {
    const cur = await running();
    if (!cur) return null;
    await DB.setSetting('timer', null);
    const dauer = Date.now() - cur.start;
    const p = await DB.get('projekte', cur.projektId);
    if (p) {
      p.zeiten = p.zeiten || [];
      if (dauer > 20000) {  // unter 20 Sekunden: Fehlstart, nicht buchen
        p.zeiten.push({ id: Util.uid(), start: cur.start, ende: Date.now(), dauer: dauer, notiz: notiz || '' });
      }
      await DB.save('projekte', p);
    }
    return { projekt: p, dauer: dauer };
  }

  function zeitSumme(p) {
    return (p.zeiten || []).reduce((s, z) => s + Util.num(z.dauer), 0);
  }
  function materialSumme(p) {
    return (p.material || []).reduce((s, m) => s + Util.num(m.kosten), 0);
  }

  /* ---------- Liste ---------- */
  async function view() {
    const all = (await DB.all('projekte')).sort((a, b) => (b.geaendert || 0) - (a.geaendert || 0));
    const cur = await running();
    let list = all;
    if (filter === 'aktiv') list = all.filter(p => p.status !== 'fertig');
    else if (filter === 'fertig') list = all.filter(p => p.status === 'fertig');

    const chips = [['aktiv', 'Aktiv'], ['fertig', 'Fertig'], ['alle', 'Alle']]
      .map(c => '<button class="chip' + (filter === c[0] ? ' on' : '') + '" data-f="' + c[0] + '">' + c[1] + '</button>').join('');

    const html = [
      '<div class="chips">' + chips + '</div>',
      all.length === 0
        ? '<div class="empty"><span class="big">&#9998;</span>Noch kein Projekt.<br>Mit <b>+</b> anlegen – dann ist es nicht mehr nur im Kopf.</div>'
        : (list.length === 0 ? '<div class="empty">Hier ist gerade nichts.</div>'
          : '<div class="list">' + list.map(p => rowHtml(p, cur)).join('') + '</div>'),
      '<button class="fab" id="pAdd">+</button>'
    ].join('');

    App.paint('Projekte', html, el => {
      Util.$$('.chip', el).forEach(c => { c.onclick = () => { filter = c.dataset.f; view(); }; });
      Util.$$('.item', el).forEach(it => { it.onclick = () => App.go('projekt', it.dataset.id); });
      Util.$('#pAdd', el).onclick = () => form();
    });
  }

  function rowHtml(p, cur) {
    const st = STATUS[p.status || 'offen'];
    const laeuft = cur && cur.projektId === p.id;
    const offen = (p.schritte || []).filter(s => !s.done).length;
    const sub = [
      Util.dur(zeitSumme(p)),
      materialSumme(p) ? Util.eur(materialSumme(p)) + ' Material' : null,
      offen ? offen + ' offene Schritte' : null
    ].filter(Boolean).join(' · ');
    return [
      '<button class="item" data-id="' + p.id + '">',
      '<span class="avatar">' + (laeuft ? '<span class="dot"></span>' : '&#9998;') + '</span>',
      '<span class="main"><span class="name">' + Util.esc(p.name) + '</span>',
      '<span class="sub">' + Util.esc(sub) + '</span></span>',
      '<span class="badge ' + (laeuft ? 'b-danger' : st.cls) + '">' + (laeuft ? 'läuft' : st.label) + '</span>',
      '</button>'
    ].join('');
  }

  /* ---------- Detail ---------- */
  async function detail(id) {
    const p = await DB.get('projekte', id);
    if (!p) { App.go('projekte'); return; }
    const cur = await running();
    const laeuft = cur && cur.projektId === p.id;
    const satz = Util.num(p.stundensatz) || await DB.setting('stundensatz', 0);
    const k = Kosten.calc(p, satz);
    const schritte = p.schritte || [];
    const fertigeSchritte = schritte.filter(s => s.done).length;

    const html = [
      /* Timer */
      '<div class="card">',
      '<div class="between"><div>',
      '<p class="small muted" style="margin:0">Arbeitszeit gesamt</p>',
      '<p class="timer-big" id="pTimer">' + (laeuft ? Util.durClock(zeitSumme(p) + (Date.now() - cur.start)) : Util.durClock(zeitSumme(p))) + '</p>',
      '</div>',
      '<button class="btn ' + (laeuft ? 'btn-danger' : 'btn-primary') + '" id="pTimerBtn">' + (laeuft ? 'Stopp' : 'Start') + '</button>',
      '</div>',
      laeuft ? '<p class="small" style="color:var(--danger);margin:8px 0 0"><span class="dot"></span> läuft seit ' + Util.dateTime(cur.start) + '</p>' : '',
      '</div>',

      /* Kosten */
      '<div class="card tight">',
      kv('Zeit', Util.dur(k.zeitMs) + (satz ? ' × ' + Util.eur(satz) : '')),
      satz ? kv('Arbeitswert', Util.eur(k.lohn)) : '',
      kv('Material', Util.eur(k.material)),
      '<div class="kv"><span class="k"><b>Gesamt</b></span><span class="v" style="color:var(--accent);font-size:17px">' + Util.eur(k.gesamt) + '</span></div>',
      '</div>',

      /* Schritte */
      '<h2>Nächste Schritte' + (schritte.length ? ' <span class="muted">(' + fertigeSchritte + '/' + schritte.length + ')</span>' : '') + '</h2>',
      '<div class="card">',
      schritte.length ? schritte.map(s =>
        '<div class="check"><input type="checkbox" id="s_' + s.id + '" data-step="' + s.id + '"' + (s.done ? ' checked' : '') + '>' +
        '<label for="s_' + s.id + '" style="' + (s.done ? 'text-decoration:line-through;color:var(--muted)' : '') + '">' + Util.esc(s.text) + '</label>' +
        '<button class="icon-btn" data-delstep="' + s.id + '" style="font-size:18px">&times;</button></div>').join('')
        : '<p class="muted small" style="margin:0 0 10px">Noch nichts eingetragen.</p>',
      '<div class="row" style="margin-top:8px"><input id="neuSchritt" placeholder="Schritt hinzufügen …" class="grow">',
      '<button class="btn btn-sm btn-primary" id="addSchritt">+</button></div>',
      '</div>',

      /* Material */
      '<h2>Verbautes Material</h2>',
      '<div class="card">',
      (p.material || []).length ? (p.material || []).map(m =>
        '<div class="kv"><span class="k">' + Util.esc(m.name) + ' <span class="muted">' + Util.fmt(m.menge, 2) + ' ' + Util.esc(m.einheit || '') + '</span></span>' +
        '<span class="v">' + Util.eur(m.kosten) + ' <button class="icon-btn" data-delmat="' + m.id + '" style="font-size:16px;min-width:30px;height:30px">&times;</button></span></div>').join('')
        : '<p class="muted small" style="margin:0 0 10px">Noch nichts gebucht.</p>',
      '<div class="btn-row" style="margin-top:8px"><button class="btn btn-sm" id="matAusLager">Aus dem Lager</button>',
      '<button class="btn btn-sm" id="matFrei">Zugekauft</button></div>',
      '</div>',

      /* Fotos */
      '<h2>Fotos</h2>',
      '<div class="card">',
      (p.fotos || []).length ? '<div class="gallery">' + (p.fotos || []).map(fid =>
        '<img data-media="' + fid + '" data-foto="' + fid + '" alt="">').join('') + '</div>' :
        '<p class="muted small" style="margin:0 0 10px">Noch keine Fotos.</p>',
      '<button class="btn btn-sm btn-block" id="addFoto" style="margin-top:8px">Foto aufnehmen</button>',
      '</div>',

      /* Sprachnotizen */
      '<h2>Sprachnotizen</h2>',
      '<div class="card stack">',
      (p.audios || []).length ? (p.audios || []).map((a, i) =>
        '<div class="audio-row"><button class="btn btn-sm" data-play="' + a + '">&#9654;</button>' +
        '<span class="grow small">Notiz ' + (i + 1) + '</span>' +
        '<button class="icon-btn" data-delaudio="' + a + '" style="font-size:18px">&times;</button></div>').join('')
        : '<p class="muted small" style="margin:0">Noch keine Sprachnotizen.</p>',
      '<button class="btn btn-sm btn-block" id="addAudio">Sprachnotiz aufnehmen</button>',
      '</div>',

      /* Notizen / Maße */
      '<h2>Maße & Notizen</h2>',
      '<div class="card">',
      '<textarea id="pNotiz" placeholder="Maße, Holzliste, was der Kunde will …">' + Util.esc(p.beschreibung || '') + '</textarea>',
      '<button class="btn btn-sm btn-block" id="saveNotiz" style="margin-top:8px">Notiz speichern</button>',
      '</div>',

      /* Zeiteinträge */
      (p.zeiten || []).length ? '<h2>Zeiten</h2><div class="card tight">' + (p.zeiten || []).slice().reverse().map(z =>
        '<div class="kv"><span class="k">' + Util.dateTime(z.start) + '</span><span class="v">' + Util.dur(z.dauer) +
        ' <button class="icon-btn" data-delzeit="' + z.id + '" style="font-size:16px;min-width:30px;height:30px">&times;</button></span></div>').join('') + '</div>' : '',

      /* Aktionen */
      '<div class="stack" style="margin-top:16px">',
      '<div class="btn-row"><button class="btn" id="pEdit">Bearbeiten</button>',
      '<button class="btn" id="pZeit">Zeit nachtragen</button></div>',
      p.status === 'fertig'
        ? '<button class="btn btn-block" id="pWieder">Wieder öffnen</button>'
        : '<button class="btn btn-primary btn-block" id="pFertig">Projekt abschließen</button>',
      '<button class="btn btn-danger btn-block" id="pDel">Projekt löschen</button>',
      '</div>'
    ].join('');

    App.paint(p.name, html, el => {
      Media.hydrate(el);
      App.showBack('projekte');
      clearInterval(tickTimer);
      if (laeuft) {
        const base = zeitSumme(p), start = cur.start, t = Util.$('#pTimer', el);
        tickTimer = setInterval(() => {
          if (!t.isConnected) { clearInterval(tickTimer); return; }
          t.textContent = Util.durClock(base + (Date.now() - start));
        }, 1000);
      }

      Util.$('#pTimerBtn', el).onclick = async () => {
        if (laeuft) { const r = await stopTimer(); Util.toast('Gestoppt: ' + Util.dur(r.dauer)); }
        else { await startTimer(p.id); Util.toast('Timer läuft'); }
        detail(id);
      };

      /* Schritte */
      Util.$$('[data-step]', el).forEach(cb => {
        cb.onchange = async () => {
          const s = (p.schritte || []).find(x => x.id === cb.dataset.step);
          if (s) { s.done = cb.checked; await DB.save('projekte', p); detail(id); }
        };
      });
      Util.$$('[data-delstep]', el).forEach(b => {
        b.onclick = async () => {
          p.schritte = (p.schritte || []).filter(x => x.id !== b.dataset.delstep);
          await DB.save('projekte', p); detail(id);
        };
      });
      const neu = Util.$('#neuSchritt', el);
      const addStep = async () => {
        const t = neu.value.trim();
        if (!t) return;
        p.schritte = p.schritte || [];
        p.schritte.push({ id: Util.uid(), text: t, done: false });
        await DB.save('projekte', p); detail(id);
      };
      Util.$('#addSchritt', el).onclick = addStep;
      neu.onkeydown = e => { if (e.key === 'Enter') addStep(); };

      /* Material */
      Util.$('#matAusLager', el).onclick = () => materialAusLager(p);
      Util.$('#matFrei', el).onclick = () => materialFrei(p);
      Util.$$('[data-delmat]', el).forEach(b => {
        b.onclick = async () => {
          const eintrag = (p.material || []).find(x => x.id === b.dataset.delmat);
          p.material = (p.material || []).filter(x => x.id !== b.dataset.delmat);
          await DB.save('projekte', p);
          if (eintrag && eintrag.materialId) {
            const m = await DB.get('material', eintrag.materialId);
            if (m) { m.menge = Util.num(m.menge) + Util.num(eintrag.menge); await DB.save('material', m); }
            Util.toast('Zurück ins Lager gebucht');
          }
          detail(id);
        };
      });

      /* Fotos */
      Util.$('#addFoto', el).onclick = async () => {
        const fid = await Media.pickPhoto();
        if (fid) { p.fotos = (p.fotos || []).concat(fid); await DB.save('projekte', p); detail(id); }
      };
      Util.$$('[data-foto]', el).forEach(img => {
        img.onclick = () => fotoAnsehen(p, img.dataset.foto, id);
      });

      /* Audio */
      Util.$('#addAudio', el).onclick = async () => {
        const aid = await Media.recordAudio();
        if (aid) { p.audios = (p.audios || []).concat(aid); await DB.save('projekte', p); detail(id); }
      };
      Util.$$('[data-play]', el).forEach(b => {
        b.onclick = async () => {
          const u = await Media.url(b.dataset.play);
          if (!u) return Util.toast('Aufnahme nicht gefunden');
          const a = new Audio(u);
          b.textContent = '⏸';
          a.onended = () => { b.textContent = '▶'; };
          a.play().catch(() => Util.toast('Abspielen nicht möglich'));
        };
      });
      Util.$$('[data-delaudio]', el).forEach(b => {
        b.onclick = async () => {
          if (!await Util.confirm('Sprachnotiz löschen?')) return;
          await Media.remove(b.dataset.delaudio);
          p.audios = (p.audios || []).filter(x => x !== b.dataset.delaudio);
          await DB.save('projekte', p); detail(id);
        };
      });

      /* Notiz */
      Util.$('#saveNotiz', el).onclick = async () => {
        p.beschreibung = Util.$('#pNotiz', el).value;
        await DB.save('projekte', p); Util.toast('Notiz gespeichert');
      };

      /* Zeiten löschen */
      Util.$$('[data-delzeit]', el).forEach(b => {
        b.onclick = async () => {
          p.zeiten = (p.zeiten || []).filter(z => z.id !== b.dataset.delzeit);
          await DB.save('projekte', p); detail(id);
        };
      });

      /* Aktionen */
      Util.$('#pEdit', el).onclick = () => form(p.id);
      Util.$('#pZeit', el).onclick = () => zeitNachtragen(p);
      const fertigBtn = Util.$('#pFertig', el);
      if (fertigBtn) fertigBtn.onclick = async () => {
        const c = await running();
        if (c && c.projektId === p.id) await stopTimer();
        p.status = 'fertig'; p.fertigAm = Date.now();
        await DB.save('projekte', p); Util.toast('Abgeschlossen'); detail(id);
      };
      const wieder = Util.$('#pWieder', el);
      if (wieder) wieder.onclick = async () => {
        p.status = 'offen'; p.fertigAm = null;
        await DB.save('projekte', p); detail(id);
      };
      Util.$('#pDel', el).onclick = async () => {
        if (!await Util.confirm('Projekt „' + p.name + '“ mit allen Zeiten und Fotos löschen?')) return;
        for (const f of (p.fotos || [])) await Media.remove(f);
        for (const a of (p.audios || [])) await Media.remove(a);
        const c = await running();
        if (c && c.projektId === p.id) await DB.setSetting('timer', null);
        await DB.del('projekte', p.id);
        Util.toast('Gelöscht'); App.go('projekte');
      };
    });
  }

  async function fotoAnsehen(p, fid, id) {
    const u = await Media.url(fid);
    Util.sheet('', '<img src="' + u + '" style="width:100%;border-radius:12px" alt="">' +
      '<button class="btn btn-danger btn-block" id="fDel" style="margin-top:12px">Foto löschen</button>' +
      '<button class="btn btn-ghost btn-block" id="fZu" style="margin-top:8px">Schließen</button>', el => {
        Util.$('#fZu', el).onclick = Util.closeSheet;
        Util.$('#fDel', el).onclick = async () => {
          await Media.remove(fid);
          p.fotos = (p.fotos || []).filter(x => x !== fid);
          await DB.save('projekte', p);
          Util.closeSheet(); detail(id);
        };
      });
  }

  /* ---------- Material buchen ---------- */
  async function materialAusLager(p) {
    const all = Util.sortBy(await DB.all('material'), 'name');
    if (!all.length) { Util.toast('Im Lager ist noch nichts erfasst'); return; }
    const html = [
      '<div class="search"><input id="mSuche" type="search" placeholder="Material suchen …"></div>',
      '<div class="list" id="mListe">' + all.map(m =>
        '<button class="item" data-id="' + m.id + '" data-name="' + Util.esc(m.name.toLowerCase()) + '">' +
        '<span class="main"><span class="name">' + Util.esc(m.name) + '</span>' +
        '<span class="sub">' + Util.fmt(m.menge, 2) + ' ' + Util.esc(m.einheit || '') + ' auf Lager' +
        (Util.num(m.preis) ? ' · ' + Util.eur(m.preis) + '/' + Util.esc(m.einheit || '') : '') + '</span></span></button>').join('') + '</div>'
    ].join('');
    Util.sheet('Material buchen', html, el => {
      const s = Util.$('#mSuche', el);
      s.oninput = () => {
        const q = s.value.toLowerCase();
        Util.$$('.item', el).forEach(it => {
          it.style.display = it.dataset.name.includes(q) ? '' : 'none';
        });
      };
      Util.$$('.item', el).forEach(it => {
        it.onclick = async () => {
          const m = await DB.get('material', it.dataset.id);
          mengeFragen(p, m);
        };
      });
    });
  }

  function mengeFragen(p, m) {
    Util.sheet(m.name, [
      '<p class="muted small">Auf Lager: ' + Util.fmt(m.menge, 2) + ' ' + Util.esc(m.einheit || '') + '</p>',
      '<div class="field"><label>Verbrauchte Menge (' + Util.esc(m.einheit || '') + ')</label>',
      '<input name="menge" type="text" inputmode="decimal" value="1" id="mengeInp"></div>',
      '<div class="field"><label>Preis je Einheit (€)</label>',
      '<input name="preis" type="text" inputmode="decimal" value="' + (Util.num(m.preis) ? Util.fmt(m.preis, 2) : '') + '"></div>',
      '<div class="btn-row"><button class="btn" id="mbAb">Abbrechen</button>',
      '<button class="btn btn-primary" id="mbOk">Buchen</button></div>'
    ].join(''), el => {
      const inp = Util.$('#mengeInp', el);
      inp.focus(); inp.select();
      Util.$('#mbAb', el).onclick = () => materialAusLager(p);
      Util.$('#mbOk', el).onclick = async () => {
        const d = Util.formData(el);
        const menge = Util.num(d.menge);
        if (menge <= 0) { Util.toast('Menge eintragen'); return; }
        const preis = Util.num(d.preis);
        p.material = p.material || [];
        p.material.push({
          id: Util.uid(), materialId: m.id, name: m.name, menge: menge,
          einheit: m.einheit, preis: preis, kosten: Math.round(menge * preis * 100) / 100, ts: Date.now()
        });
        await DB.save('projekte', p);
        await Lager.buchen(m.id, menge);
        Util.closeSheet();
        Util.toast(Util.fmt(menge, 2) + ' ' + (m.einheit || '') + ' gebucht, Lager aktualisiert');
        detail(p.id);
      };
    });
  }

  function materialFrei(p) {
    Util.sheet('Zugekauftes Material', [
      '<div class="field"><label>Bezeichnung</label><input name="name" placeholder="z. B. Sonderbeschlag"></div>',
      '<div class="fields2">',
      '<div class="field"><label>Menge</label><input name="menge" type="text" inputmode="decimal" value="1"></div>',
      '<div class="field"><label>Einheit</label><select name="einheit">' +
        Lager.EINHEITEN.map(e => '<option>' + e + '</option>').join('') + '</select></div>',
      '</div>',
      '<div class="field"><label>Kosten gesamt (€)</label><input name="kosten" type="text" inputmode="decimal"></div>',
      '<div class="check"><input type="checkbox" id="insLager" name="insLager"><label for="insLager">Auch ins Lager aufnehmen</label></div>',
      '<div class="btn-row"><button class="btn" id="mfAb">Abbrechen</button>',
      '<button class="btn btn-primary" id="mfOk">Hinzufügen</button></div>'
    ].join(''), el => {
      Util.$('#mfAb', el).onclick = () => detail(p.id);
      Util.$('#mfOk', el).onclick = async () => {
        const d = Util.formData(el);
        if (!d.name.trim()) { Util.toast('Bitte Bezeichnung eintragen'); return; }
        const menge = Util.num(d.menge) || 1;
        const kosten = Util.num(d.kosten);
        p.material = p.material || [];
        p.material.push({
          id: Util.uid(), materialId: null, name: d.name.trim(), menge: menge,
          einheit: d.einheit, preis: menge ? kosten / menge : kosten, kosten: kosten, ts: Date.now()
        });
        await DB.save('projekte', p);
        if (d.insLager) {
          await DB.save('material', {
            name: d.name.trim(), kategorie: '', menge: 0, einheit: d.einheit, mindest: 0,
            ort: '', preis: menge ? Math.round((kosten / menge) * 100) / 100 : '', lieferant: '', artnr: '', notiz: ''
          });
        }
        Util.closeSheet(); Util.toast('Hinzugefügt'); detail(p.id);
      };
    });
  }

  function zeitNachtragen(p) {
    Util.sheet('Zeit nachtragen', [
      '<div class="field"><label>Datum</label><input name="datum" type="date" value="' + Util.dateInput() + '"></div>',
      '<div class="fields2">',
      '<div class="field"><label>Stunden</label><input name="std" type="text" inputmode="decimal" value="0"></div>',
      '<div class="field"><label>Minuten</label><input name="min" type="text" inputmode="numeric" value="30"></div>',
      '</div>',
      '<div class="field"><label>Notiz</label><input name="notiz" placeholder="woran gearbeitet"></div>',
      '<div class="btn-row"><button class="btn" id="znAb">Abbrechen</button>',
      '<button class="btn btn-primary" id="znOk">Eintragen</button></div>'
    ].join(''), el => {
      Util.$('#znAb', el).onclick = () => detail(p.id);
      Util.$('#znOk', el).onclick = async () => {
        const d = Util.formData(el);
        const ms = (Util.num(d.std) * 3600 + Util.num(d.min) * 60) * 1000;
        if (ms <= 0) { Util.toast('Bitte eine Dauer eintragen'); return; }
        const start = Util.fromDateInput(d.datum) || Date.now();
        p.zeiten = p.zeiten || [];
        p.zeiten.push({ id: Util.uid(), start: start, ende: start + ms, dauer: ms, notiz: d.notiz.trim() });
        await DB.save('projekte', p);
        Util.closeSheet(); Util.toast('Eingetragen'); detail(p.id);
      };
    });
  }

  /* ---------- Formular ---------- */
  async function form(id) {
    const p = id ? await DB.get('projekte', id) : {
      name: '', kunde: '', status: 'offen', beschreibung: '', stundensatz: '',
      schritte: [], material: [], zeiten: [], fotos: [], audios: []
    };
    const satzDefault = await DB.setting('stundensatz', 0);
    const html = [
      '<div class="field"><label>Projektname</label><input name="name" value="' + Util.esc(p.name) + '" placeholder="z. B. Regal für die Scheune"></div>',
      '<div class="field"><label>Für wen / Auftraggeber</label><input name="kunde" value="' + Util.esc(p.kunde || '') + '" placeholder="optional"></div>',
      '<div class="field"><label>Status</label><select name="status">' +
        Object.keys(STATUS).map(k => '<option value="' + k + '"' + ((p.status || 'offen') === k ? ' selected' : '') + '>' + STATUS[k].label + '</option>').join('') +
        '</select></div>',
      '<div class="field"><label>Stundensatz (€) – leer = Standard ' + Util.eur(satzDefault) + '</label>',
      '<input name="stundensatz" type="text" inputmode="decimal" value="' + (Util.num(p.stundensatz) ? Util.fmt(p.stundensatz, 2) : '') + '"></div>',
      '<div class="field"><label>Maße & Notizen</label><textarea name="beschreibung">' + Util.esc(p.beschreibung || '') + '</textarea></div>',
      '<div class="btn-row"><button class="btn" id="pfAb">Abbrechen</button>',
      '<button class="btn btn-primary" id="pfOk">Speichern</button></div>'
    ].join('');

    Util.sheet(id ? 'Projekt bearbeiten' : 'Neues Projekt', html, el => {
      Util.$('#pfAb', el).onclick = () => id ? detail(id) : Util.closeSheet();
      Util.$('#pfOk', el).onclick = async () => {
        const d = Util.formData(el);
        if (!d.name.trim()) { Util.toast('Bitte einen Namen eintragen'); return; }
        Object.assign(p, {
          name: d.name.trim(), kunde: d.kunde.trim(), status: d.status,
          stundensatz: d.stundensatz === '' ? '' : Util.num(d.stundensatz),
          beschreibung: d.beschreibung
        });
        const saved = await DB.save('projekte', p);
        Util.closeSheet(); Util.toast('Gespeichert');
        App.go('projekt', saved.id);
      };
    });
  }

  return { view, detail, form, running, startTimer, stopTimer, zeitSumme, materialSumme, STATUS };
})();

function kv(k, v) {
  if (v === undefined || v === null || v === '') v = '–';
  return '<div class="kv"><span class="k">' + Util.esc(k) + '</span><span class="v">' + Util.esc(v) + '</span></div>';
}
