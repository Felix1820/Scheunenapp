/* ---------------------------------------------------------------
   lager.js – Material: Bestand, Mindestmenge, Einkaufsliste
----------------------------------------------------------------*/
const Lager = (function () {
  const EINHEITEN = ['Stk', 'Pack', 'm', 'lfm', 'm²', 'kg', 'g', 'l', 'ml', 'Rolle', 'Sack', 'Dose', 'Tube'];
  let filter = { q: '', kat: '', knapp: false };

  function istKnapp(m) {
    return Util.num(m.mindest) > 0 && Util.num(m.menge) <= Util.num(m.mindest);
  }
  function fehlmenge(m) {
    const soll = Util.num(m.mindest) * 2;
    return Math.max(Util.num(m.mindest), soll - Util.num(m.menge));
  }

  async function lowStock() {
    const all = await DB.all('material');
    return all.filter(istKnapp);
  }

  /* ---------- Liste ---------- */
  async function view() {
    const all = Util.sortBy(await DB.all('material'), 'name');
    const kats = Array.from(new Set(all.map(m => m.kategorie).filter(Boolean))).sort((a, b) => a.localeCompare(b, 'de'));
    const knappCount = all.filter(istKnapp).length;

    let list = all;
    if (filter.kat) list = list.filter(m => m.kategorie === filter.kat);
    if (filter.knapp) list = list.filter(istKnapp);
    if (filter.q) {
      const q = filter.q.toLowerCase();
      list = list.filter(m => (m.name + ' ' + (m.kategorie || '') + ' ' + (m.ort || '') + ' ' + (m.artnr || '')).toLowerCase().includes(q));
    }

    const chips = ['<button class="chip' + (!filter.kat && !filter.knapp ? ' on' : '') + '" data-kat="">Alle</button>',
      '<button class="chip' + (filter.knapp ? ' on' : '') + '" data-knapp="1">Knapp' + (knappCount ? ' (' + knappCount + ')' : '') + '</button>']
      .concat(kats.map(k => '<button class="chip' + (filter.kat === k ? ' on' : '') + '" data-kat="' + Util.esc(k) + '">' + Util.esc(k) + '</button>'))
      .join('');

    const html = [
      '<div class="search"><input id="lagerSuche" type="search" placeholder="Material suchen …" value="' + Util.esc(filter.q) + '"></div>',
      '<div class="chips">' + chips + '</div>',
      all.length === 0
        ? '<div class="empty"><span class="big">&#9776;</span>Noch kein Material erfasst.<br>Mit <b>+</b> das erste Material anlegen.</div>'
        : (list.length === 0 ? '<div class="empty">Nichts gefunden.</div>' : '<div class="list">' + list.map(rowHtml).join('') + '</div>'),
      '<button class="fab" id="lagerAdd">+</button>'
    ].join('');

    App.paint('Lager', html, el => {
      const s = Util.$('#lagerSuche', el);
      s.oninput = Util.debounce(() => { filter.q = s.value; view(); }, 250);
      Util.$$('.chip', el).forEach(c => {
        c.onclick = () => {
          if (c.dataset.knapp) { filter.knapp = !filter.knapp; filter.kat = ''; }
          else { filter.kat = c.dataset.kat; filter.knapp = false; }
          view();
        };
      });
      Util.$$('.item', el).forEach(it => { it.onclick = () => detail(it.dataset.id); });
      Util.$('#lagerAdd', el).onclick = () => form();
      Media.hydrate(el);
    });
  }

  function rowHtml(m) {
    const knapp = istKnapp(m);
    const bestand = Util.fmt(m.menge, 2) + ' ' + Util.esc(m.einheit || '');
    const sub = [m.ort, m.kategorie].filter(Boolean).map(Util.esc).join(' · ');
    return [
      '<button class="item" data-id="' + m.id + '">',
      m.fotoId ? '<img class="thumb" data-media="' + m.fotoId + '" alt="">' : '<span class="avatar">&#9776;</span>',
      '<span class="main"><span class="name">' + Util.esc(m.name) + '</span>',
      '<span class="sub">' + (sub || '&nbsp;') + '</span></span>',
      '<span class="right"><span class="badge ' + (knapp ? 'b-danger' : 'b-grey') + '">' + bestand + '</span>',
      knapp ? '<span class="small" style="color:var(--danger)">nachkaufen</span>' : '',
      '</span></button>'
    ].join('');
  }

  /* ---------- Detail ---------- */
  async function detail(id) {
    const m = await DB.get('material', id);
    if (!m) { Util.toast('Material nicht gefunden'); return; }
    const knapp = istKnapp(m);
    const pct = Util.num(m.mindest) > 0
      ? Math.max(4, Math.min(100, (Util.num(m.menge) / (Util.num(m.mindest) * 2)) * 100)) : 100;
    const barCls = knapp ? 'bar low' : (pct < 60 ? 'bar mid' : 'bar');

    const html = [
      m.fotoId ? '<img data-media="' + m.fotoId + '" style="width:100%;max-height:190px;object-fit:cover;border-radius:12px;margin-bottom:12px" alt="">' : '',
      '<div class="center stack" style="margin-bottom:14px">',
      '<div class="stepper" style="justify-content:center">',
      '<button id="minus">&minus;</button>',
      '<span class="val" id="mengeVal">' + Util.fmt(m.menge, 2) + '</span>',
      '<button id="plus">+</button>',
      '<span class="muted" style="min-width:42px;text-align:left">' + Util.esc(m.einheit || '') + '</span>',
      '</div>',
      '<div class="' + barCls + '"><i style="width:' + pct + '%"></i></div>',
      knapp ? '<p class="small" style="color:var(--danger);margin:6px 0 0">Unter Mindestmenge – steht auf der Einkaufsliste</p>' : '',
      '</div>',
      '<div class="card tight">',
      kv('Kategorie', m.kategorie),
      kv('Ort', m.ort),
      kv('Mindestmenge', Util.num(m.mindest) ? Util.fmt(m.mindest, 2) + ' ' + (m.einheit || '') : '–'),
      kv('Preis', Util.num(m.preis) ? Util.eur(m.preis) + ' / ' + (m.einheit || 'Einheit') : '–'),
      kv('Wert im Lager', Util.num(m.preis) ? Util.eur(Util.num(m.preis) * Util.num(m.menge)) : '–'),
      kv('Lieferant', m.lieferant),
      kv('Art.-Nr.', m.artnr),
      '</div>',
      m.notiz ? '<div class="card"><p class="small muted">Notiz</p><p style="margin:0;white-space:pre-wrap">' + Util.esc(m.notiz) + '</p></div>' : '',
      '<div class="btn-row" style="margin-top:12px"><button class="btn" id="mEdit">Bearbeiten</button>',
      '<button class="btn" id="mQr">QR-Etikett</button></div>',
      '<button class="btn btn-danger btn-block" id="mDel" style="margin-top:8px">Löschen</button>'
    ].join('');

    Util.sheet(m.name, html, el => {
      Media.hydrate(el);
      const step = Util.num(m.mengeSchritt) || schrittFuer(m);
      Util.$('#minus', el).onclick = () => aendern(m, -step, el);
      Util.$('#plus', el).onclick = () => aendern(m, step, el);
      Util.$('#mEdit', el).onclick = () => form(m.id);
      Util.$('#mQr', el).onclick = () => { Util.closeSheet(); Etiketten.single('material', m.id, m.name); };
      Util.$('#mDel', el).onclick = async () => {
        if (await Util.confirm('„' + m.name + '“ wirklich löschen?')) {
          if (m.fotoId) await Media.remove(m.fotoId);
          await DB.del('material', m.id);
          Util.closeSheet(); Util.toast('Gelöscht'); view();
        }
      };
    });
  }

  function schrittFuer(m) {
    const e = (m.einheit || '').toLowerCase();
    if (['kg', 'l', 'm', 'lfm', 'm²'].includes(e)) return 0.5;
    return 1;
  }

  async function aendern(m, delta, el) {
    m.menge = Math.max(0, Math.round((Util.num(m.menge) + delta) * 1000) / 1000);
    await DB.save('material', m);
    const v = Util.$('#mengeVal', el);
    if (v) v.textContent = Util.fmt(m.menge, 2);
    if (navigator.vibrate) navigator.vibrate(15);
    view();
  }

  function kv(k, v) {
    if (v === undefined || v === null || v === '') v = '–';
    return '<div class="kv"><span class="k">' + Util.esc(k) + '</span><span class="v">' + Util.esc(v) + '</span></div>';
  }

  /* ---------- Formular ---------- */
  async function form(id, vorgabe) {
    const m = id ? await DB.get('material', id) : Object.assign({
      name: '', kategorie: '', menge: 0, einheit: 'Stk', mindest: 0,
      ort: '', preis: '', lieferant: '', artnr: '', notiz: '', fotoId: null
    }, vorgabe || {});
    const alle = await DB.all('material');
    const kats = Array.from(new Set(alle.map(x => x.kategorie).filter(Boolean)));
    const orte = Array.from(new Set(alle.map(x => x.ort).filter(Boolean)
      .concat((await DB.all('orte')).map(o => o.name))));

    const html = [
      '<div class="field"><label>Bezeichnung</label><input name="name" value="' + Util.esc(m.name) + '" placeholder="z. B. Spax 4×40" autocomplete="off"></div>',
      '<div class="fields2">',
      '<div class="field"><label>Bestand</label><input name="menge" type="text" inputmode="decimal" value="' + Util.fmt(m.menge, 2) + '"></div>',
      '<div class="field"><label>Einheit</label><select name="einheit">' +
        EINHEITEN.map(e => '<option' + (e === m.einheit ? ' selected' : '') + '>' + e + '</option>').join('') + '</select></div>',
      '</div>',
      '<div class="fields2">',
      '<div class="field"><label>Mindestmenge</label><input name="mindest" type="text" inputmode="decimal" value="' + Util.fmt(m.mindest, 2) + '"></div>',
      '<div class="field"><label>Preis je Einheit (€)</label><input name="preis" type="text" inputmode="decimal" value="' + (Util.num(m.preis) ? Util.fmt(m.preis, 2) : '') + '"></div>',
      '</div>',
      '<div class="field"><label>Kategorie</label><input name="kategorie" list="katList" value="' + Util.esc(m.kategorie) + '" placeholder="z. B. Schrauben">',
      '<datalist id="katList">' + kats.map(k => '<option value="' + Util.esc(k) + '">').join('') + '</datalist></div>',
      '<div class="field"><label>Lagerort</label><input name="ort" list="ortList" value="' + Util.esc(m.ort) + '" placeholder="z. B. Regal B, Kiste 3">',
      '<datalist id="ortList">' + orte.map(o => '<option value="' + Util.esc(o) + '">').join('') + '</datalist></div>',
      '<div class="fields2">',
      '<div class="field"><label>Lieferant</label><input name="lieferant" value="' + Util.esc(m.lieferant) + '"></div>',
      '<div class="field"><label>Art.-Nr.</label><input name="artnr" value="' + Util.esc(m.artnr) + '"></div>',
      '</div>',
      '<div class="field"><label>Notiz</label><textarea name="notiz" placeholder="Was man wissen sollte …">' + Util.esc(m.notiz) + '</textarea></div>',
      '<div class="field"><label>Foto</label><div class="row" id="fotoBox">',
      m.fotoId ? '<img class="thumb" data-media="' + m.fotoId + '" alt="">' : '',
      '<button class="btn btn-sm" id="fotoBtn" type="button">' + (m.fotoId ? 'Foto ersetzen' : 'Foto aufnehmen') + '</button>',
      m.fotoId ? '<button class="btn btn-sm btn-ghost" id="fotoDel" type="button">Entfernen</button>' : '',
      '</div></div>',
      '<div class="btn-row" style="margin-top:6px"><button class="btn" id="fAbbruch">Abbrechen</button>',
      '<button class="btn btn-primary" id="fSpeichern">Speichern</button></div>'
    ].join('');

    Util.sheet(id ? 'Material bearbeiten' : 'Neues Material', html, el => {
      Media.hydrate(el);
      let fotoId = m.fotoId || null;
      const fb = Util.$('#fotoBtn', el);
      if (fb) fb.onclick = async () => {
        const nid = await Media.pickPhoto();
        if (nid) { fotoId = nid; Util.toast('Foto gespeichert'); fb.textContent = 'Foto ersetzen'; }
      };
      const fd = Util.$('#fotoDel', el);
      if (fd) fd.onclick = () => { fotoId = null; fd.remove(); Util.toast('Foto entfernt'); };
      Util.$('#fAbbruch', el).onclick = () => id ? detail(id) : Util.closeSheet();
      Util.$('#fSpeichern', el).onclick = async () => {
        const d = Util.formData(el);
        if (!d.name.trim()) { Util.toast('Bitte eine Bezeichnung eintragen'); return; }
        const obj = Object.assign(m, {
          name: d.name.trim(), kategorie: d.kategorie.trim(), menge: Util.num(d.menge),
          einheit: d.einheit, mindest: Util.num(d.mindest), ort: d.ort.trim(),
          preis: d.preis === '' ? '' : Util.num(d.preis), lieferant: d.lieferant.trim(),
          artnr: d.artnr.trim(), notiz: d.notiz.trim(), fotoId: fotoId
        });
        await DB.save('material', obj);
        Util.closeSheet(); Util.toast('Gespeichert');
        if (App.route === 'lager') view(); else App.go('lager');
      };
    });
  }

  /* ---------- Verbrauch buchen (aus Projekten) ---------- */
  async function buchen(materialId, menge) {
    const m = await DB.get('material', materialId);
    if (!m) return null;
    m.menge = Math.max(0, Math.round((Util.num(m.menge) - Util.num(menge)) * 1000) / 1000);
    await DB.save('material', m);
    return m;
  }

  return { view, detail, form, lowStock, istKnapp, fehlmenge, buchen, EINHEITEN };
})();
