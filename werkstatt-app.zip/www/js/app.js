/* ---------------------------------------------------------------
   app.js – Start, Navigation, Scannen, Einstellungen
----------------------------------------------------------------*/
const App = (function () {
  const TABS = ['start', 'lager', 'werkzeug', 'projekte', 'mehr'];
  let route = 'start', param = null, backRoute = null, dashTimer = null;

  /* ---------- Rendern ---------- */
  function paint(title, html, bind) {
    const v = Util.$('#view');
    Util.$('#title').textContent = title;
    Util.$('#backBtn').classList.add('hidden');
    backRoute = null;
    v.innerHTML = html;
    v.scrollTop = 0;
    window.scrollTo(0, 0);
    if (bind) bind(v);
  }

  function showBack(r) {
    backRoute = r;
    Util.$('#backBtn').classList.remove('hidden');
  }

  /* ---------- Navigation ---------- */
  function go(r, p) {
    route = r; param = p || null;
    api.route = r;
    Util.$$('#tabbar .tab').forEach(t => {
      const on = t.dataset.tab === r || (r === 'projekt' && t.dataset.tab === 'projekte') ||
        (['kosten', 'rechner', 'etiketten', 'einkauf', 'backup', 'einstellungen'].includes(r) && t.dataset.tab === 'mehr');
      t.classList.toggle('active', on);
    });
    clearInterval(dashTimer);
    if (r === 'start') return dashboard();
    if (r === 'lager') return Lager.view();
    if (r === 'werkzeug') return Werkzeug.view();
    if (r === 'projekte') return Projekte.view();
    if (r === 'projekt') return Projekte.detail(p);
    if (r === 'mehr') return mehr();
    if (r === 'kosten') return Kosten.view();
    if (r === 'rechner') return Rechner.view(p);
    if (r === 'etiketten') return Etiketten.view();
    if (r === 'einkauf') return Einkauf.view();
    if (r === 'backup') return Backup.view();
    if (r === 'einstellungen') return einstellungen();
    return dashboard();
  }

  /* ---------- Start / Dashboard ---------- */
  async function dashboard() {
    const [projekte, knapp, wzWarn, timer, satz] = await Promise.all([
      DB.all('projekte'), Lager.lowStock(), Werkzeug.warnungen(), Projekte.running(), DB.setting('stundensatz', 0)
    ]);
    const aktiv = projekte.filter(p => p.status !== 'fertig');
    const timerP = timer ? projekte.find(p => p.id === timer.projektId) : null;

    /* Zeit diese Woche */
    const d = new Date(); d.setHours(0, 0, 0, 0);
    const wochenStart = d.getTime() - ((d.getDay() + 6) % 7) * 86400000;
    let wocheMs = 0;
    projekte.forEach(p => (p.zeiten || []).forEach(z => { if (z.start >= wochenStart) wocheMs += Util.num(z.dauer); }));
    if (timer && timer.start >= wochenStart) wocheMs += Date.now() - timer.start;

    const material = await DB.all('material');
    const lagerwert = material.reduce((s, m) => s + Util.num(m.preis) * Util.num(m.menge), 0);

    const html = [
      timerP ? [
        '<div class="card" style="border-color:var(--accent)">',
        '<p class="small muted" style="margin:0"><span class="dot"></span> läuft: ' + Util.esc(timerP.name) + '</p>',
        '<div class="between" style="margin-top:6px">',
        '<span class="timer-big" id="dashTimer">' + Util.durClock(Projekte.zeitSumme(timerP) + (Date.now() - timer.start)) + '</span>',
        '<button class="btn btn-danger" id="dashStop">Stopp</button></div>',
        '</div>'
      ].join('') : '',

      '<div class="row" style="gap:8px;margin-bottom:10px">',
      kachel('Diese Woche', Util.dur(wocheMs)),
      kachel('Projekte offen', String(aktiv.length)),
      '</div>',

      '<div class="row wrap" style="gap:8px;margin-bottom:6px">',
      '<button class="btn grow" id="qScan">QR scannen</button>',
      '<button class="btn grow" id="qProjekt">Projekt starten</button>',
      '</div>',
      '<div class="row wrap" style="gap:8px">',
      '<button class="btn grow" id="qMat">Material +</button>',
      '<button class="btn grow" id="qWz">Werkzeug +</button>',
      '</div>',

      knapp.length ? [
        '<h2>Geht zur Neige (' + knapp.length + ')</h2>',
        '<div class="list">' + Util.sortBy(knapp, 'name').slice(0, 4).map(m =>
          '<button class="item" data-mat="' + m.id + '"><span class="avatar">&#9888;</span>' +
          '<span class="main"><span class="name">' + Util.esc(m.name) + '</span>' +
          '<span class="sub">noch ' + Util.fmt(m.menge, 2) + ' ' + Util.esc(m.einheit || '') + '</span></span>' +
          '<span class="badge b-danger">nachkaufen</span></button>').join('') + '</div>',
        knapp.length > 4 ? '<button class="btn btn-sm btn-block" id="zurListe" style="margin-top:8px">Ganze Einkaufsliste</button>' : ''
      ].join('') : '',

      wzWarn.length ? [
        '<h2>Werkzeug im Blick</h2>',
        '<div class="list">' + wzWarn.slice(0, 4).map(w => {
          const p = Werkzeug.problemeVon(w)[0];
          return '<button class="item" data-wz="' + w.id + '"><span class="avatar">&#9874;</span>' +
            '<span class="main"><span class="name">' + Util.esc(w.name) + '</span>' +
            '<span class="sub">' + Util.esc(w.ort || '') + '</span></span>' +
            '<span class="badge ' + p.cls + '">' + Util.esc(p.kurz || p.text) + '</span></button>';
        }).join('') + '</div>'
      ].join('') : '',

      aktiv.length ? [
        '<h2>Angefangene Arbeiten</h2>',
        '<div class="list">' + aktiv.slice(0, 5).map(p =>
          '<button class="item" data-proj="' + p.id + '"><span class="avatar">&#9998;</span>' +
          '<span class="main"><span class="name">' + Util.esc(p.name) + '</span>' +
          '<span class="sub">' + Util.dur(Projekte.zeitSumme(p)) +
          ((p.schritte || []).filter(s => !s.done).length ? ' · ' + (p.schritte || []).filter(s => !s.done).length + ' offen' : '') +
          '</span></span><span class="muted">&#8250;</span></button>').join('') + '</div>'
      ].join('') : '',

      (!aktiv.length && !knapp.length && !wzWarn.length) ? [
        '<div class="empty"><span class="big">&#9874;</span>',
        'Willkommen in der Werkstatt.<br>Leg los: Werkzeug erfassen, Material aufnehmen<br>oder ein Projekt starten.</div>'
      ].join('') : '',

      lagerwert ? '<p class="small muted center" style="margin-top:16px">Materialwert im Lager: ' + Util.eur(lagerwert) + '</p>' : ''
    ].join('');

    paint('Werkstatt', html, el => {
      if (timerP) {
        const base = Projekte.zeitSumme(timerP), start = timer.start, t = Util.$('#dashTimer', el);
        dashTimer = setInterval(() => {
          if (!t.isConnected) { clearInterval(dashTimer); return; }
          t.textContent = Util.durClock(base + (Date.now() - start));
        }, 1000);
        Util.$('#dashStop', el).onclick = async () => {
          const r = await Projekte.stopTimer();
          Util.toast('Gestoppt: ' + Util.dur(r.dauer));
          dashboard();
        };
      }
      Util.$('#qScan', el).onclick = scan;
      Util.$('#qProjekt', el).onclick = () => Projekte.form();
      Util.$('#qMat', el).onclick = () => Lager.form();
      Util.$('#qWz', el).onclick = () => Werkzeug.form();
      const zl = Util.$('#zurListe', el);
      if (zl) zl.onclick = () => go('einkauf');
      Util.$$('[data-mat]', el).forEach(b => { b.onclick = () => Lager.detail(b.dataset.mat); });
      Util.$$('[data-wz]', el).forEach(b => { b.onclick = () => Werkzeug.detail(b.dataset.wz); });
      Util.$$('[data-proj]', el).forEach(b => { b.onclick = () => go('projekt', b.dataset.proj); });
    });
  }

  function kachel(label, wert) {
    return '<div class="card grow" style="margin:0;text-align:center;padding:12px 8px">' +
      '<div class="small muted">' + label + '</div>' +
      '<div style="font-size:20px;font-weight:700;margin-top:2px">' + Util.esc(wert) + '</div></div>';
  }

  /* ---------- Mehr ---------- */
  async function mehr() {
    const ek = await Einkauf.anzahl();
    const eintraege = [
      ['einkauf', '&#128722;', 'Einkaufsliste', ek ? ek + ' offen' : 'alles da'],
      ['kosten', '&#8721;', 'Zeit & Kosten', 'Auswertung je Projekt, CSV'],
      ['rechner', '&#9881;', 'Rechner', 'Zuschnitt, Bedarf, Maße, Bohrer'],
      ['etiketten', '&#9635;', 'QR-Etiketten & Orte', 'Regale und Kisten beschriften'],
      ['backup', '&#8681;', 'Sicherung', 'Daten sichern und zurückholen'],
      ['einstellungen', '&#9788;', 'Einstellungen', 'Stundensatz, Info']
    ];
    const html = '<div class="list">' + eintraege.map(e =>
      '<button class="item" data-go="' + e[0] + '"><span class="avatar">' + e[1] + '</span>' +
      '<span class="main"><span class="name">' + e[2] + '</span><span class="sub">' + e[3] + '</span></span>' +
      '<span class="muted">&#8250;</span></button>').join('') + '</div>';
    paint('Mehr', html, el => {
      Util.$$('[data-go]', el).forEach(b => { b.onclick = () => go(b.dataset.go); });
    });
  }

  /* ---------- Einstellungen ---------- */
  async function einstellungen() {
    const satz = await DB.setting('stundensatz', 0);
    const html = [
      '<div class="card">',
      '<div class="field"><label>Standard-Stundensatz (€)</label>',
      '<input id="setSatz" type="text" inputmode="decimal" value="' + (satz ? Util.fmt(satz, 2) : '') + '" placeholder="z. B. 45"></div>',
      '<button class="btn btn-primary btn-block" id="setSave">Speichern</button>',
      '</div>',
      '<div class="card">',
      '<p style="margin:0 0 8px"><b>Werkstatt</b> <span class="muted small">Version 1.0</span></p>',
      '<p class="small muted" style="margin:0">Läuft komplett offline auf diesem Gerät. Kamera wird für QR-Codes und Fotos gebraucht, das Mikrofon für Sprachnotizen. Es werden keine Daten verschickt.</p>',
      '</div>',
      '<div class="card">',
      '<p class="small muted" style="margin:0 0 8px">Beispieldaten anlegen, um alles auszuprobieren (fügt Material, Werkzeug und ein Projekt hinzu).</p>',
      '<button class="btn btn-sm btn-block" id="setDemo">Beispieldaten einfügen</button>',
      '</div>'
    ].join('');
    paint('Einstellungen', html, el => {
      showBack('mehr');
      Util.$('#setSave', el).onclick = async () => {
        await DB.setSetting('stundensatz', Util.num(Util.$('#setSatz', el).value));
        Util.toast('Gespeichert');
      };
      Util.$('#setDemo', el).onclick = async () => {
        if (!await Util.confirm('Beispieldaten hinzufügen?', 'Einfügen')) return;
        await demoDaten();
        Util.toast('Beispiele angelegt'); go('start');
      };
    });
  }

  async function demoDaten() {
    const mats = [
      { name: 'Spax 4×40 Senkkopf', kategorie: 'Schrauben', menge: 180, einheit: 'Stk', mindest: 200, ort: 'Regal A', preis: 0.09, lieferant: 'Baumarkt' },
      { name: 'Fichte Leimholz 18 mm', kategorie: 'Holz', menge: 3, einheit: 'm²', mindest: 2, ort: 'Holzlager', preis: 24.9 },
      { name: 'Holzleim wasserfest D3', kategorie: 'Kleber', menge: 0.5, einheit: 'l', mindest: 1, ort: 'Regal B', preis: 8.5 },
      { name: 'Schleifpapier K120', kategorie: 'Verbrauch', menge: 12, einheit: 'Stk', mindest: 10, ort: 'Schublade 2', preis: 0.8 }
    ];
    for (const m of mats) await DB.save('material', Object.assign({ notiz: '', artnr: '' }, m));
    const wz = [
      { name: 'Akkuschrauber', kategorie: 'Elektro', ort: 'Werkbank', zustand: 'ok', intervall: '365' },
      { name: 'Kreissäge', kategorie: 'Elektro', ort: 'Scheune hinten', zustand: 'wartung', wartungFaellig: Date.now() + 3 * 86400000, intervall: '180' },
      { name: 'Bandmaß 5 m', kategorie: 'Messen', ort: 'Werkbank', zustand: 'ok', verliehenAn: 'Nachbar Klaus', verliehenSeit: Date.now() - 6 * 86400000 }
    ];
    for (const w of wz) await DB.save('werkzeug', Object.assign({ notiz: '', seriennr: '', kaufpreis: '' }, w));
    for (const o of ['Regal A', 'Regal B', 'Holzlager', 'Schublade 2']) await DB.save('orte', { name: o, typ: 'Regal' });
    await DB.save('projekte', {
      name: 'Werkbank-Regal', status: 'offen', kunde: '', beschreibung: 'Maße: 180 × 40 × 200 cm, 5 Böden',
      schritte: [{ id: Util.uid(), text: 'Holz zuschneiden', done: true }, { id: Util.uid(), text: 'Schleifen', done: false },
                 { id: Util.uid(), text: 'Montieren', done: false }],
      material: [], zeiten: [{ id: Util.uid(), start: Date.now() - 86400000, ende: Date.now() - 79200000, dauer: 6800000, notiz: 'Zuschnitt' }],
      fotos: [], audios: [], stundensatz: ''
    });
    if (!await DB.setting('stundensatz', 0)) await DB.setSetting('stundensatz', 45);
  }

  /* ---------- Scannen ---------- */
  async function scan() {
    const code = await Media.scan();
    if (!code) return;
    await handleCode(code);
  }

  async function handleCode(code) {
    const p = Etiketten.parse(code);
    if (p) {
      if (p.typ === 'material') {
        const m = await DB.get('material', p.id);
        if (m) return Lager.detail(m.id);
      } else if (p.typ === 'werkzeug') {
        const w = await DB.get('werkzeug', p.id);
        if (w) return Werkzeug.detail(w.id);
      } else if (p.typ === 'ort') {
        const o = await DB.get('orte', p.id);
        if (o) return Etiketten.ortDetail(o.id);
      }
      Util.toast('Etikett gehört zu einem gelöschten Eintrag');
      return;
    }
    /* fremder Barcode: zugeordnet? */
    const mat = (await DB.all('material')).find(m => m.code === code || (m.artnr && m.artnr === code));
    if (mat) return Lager.detail(mat.id);
    const wz = (await DB.all('werkzeug')).find(w => w.code === code);
    if (wz) return Werkzeug.detail(wz.id);
    unbekannterCode(code);
  }

  function unbekannterCode(code) {
    Util.sheet('Unbekannter Code', [
      '<p class="small muted" style="word-break:break-all">' + Util.esc(code) + '</p>',
      '<p>Diesen Code kennt die App noch nicht. Du kannst ihn einem Eintrag zuordnen – dann öffnet der nächste Scan direkt den richtigen.</p>',
      '<div class="stack">',
      '<button class="btn btn-block" id="ucMat">Vorhandenem Material zuordnen</button>',
      '<button class="btn btn-block" id="ucWz">Vorhandenem Werkzeug zuordnen</button>',
      '<button class="btn btn-primary btn-block" id="ucNeu">Neues Material damit anlegen</button>',
      '<button class="btn btn-ghost btn-block" id="ucZu">Abbrechen</button>',
      '</div>'
    ].join(''), el => {
      Util.$('#ucZu', el).onclick = Util.closeSheet;
      Util.$('#ucMat', el).onclick = () => zuordnen('material', code);
      Util.$('#ucWz', el).onclick = () => zuordnen('werkzeug', code);
      Util.$('#ucNeu', el).onclick = () => { Util.closeSheet(); Lager.form(null, { artnr: code, code: code }); };
    });
  }

  async function zuordnen(store, code) {
    const list = Util.sortBy(await DB.all(store), 'name');
    if (!list.length) { Util.toast('Da ist noch nichts angelegt'); return; }
    Util.sheet('Code zuordnen', [
      '<div class="search"><input id="zSuche" type="search" placeholder="Suchen …"></div>',
      '<div class="list">' + list.map(x =>
        '<button class="item" data-id="' + x.id + '" data-name="' + Util.esc(x.name.toLowerCase()) + '">' +
        '<span class="main"><span class="name">' + Util.esc(x.name) + '</span></span></button>').join('') + '</div>'
    ].join(''), el => {
      const s = Util.$('#zSuche', el);
      s.oninput = () => {
        const q = s.value.toLowerCase();
        Util.$$('.item', el).forEach(i => { i.style.display = i.dataset.name.includes(q) ? '' : 'none'; });
      };
      Util.$$('.item', el).forEach(b => {
        b.onclick = async () => {
          const obj = await DB.get(store, b.dataset.id);
          obj.code = code;
          await DB.save(store, obj);
          Util.toast('Zugeordnet');
          store === 'material' ? Lager.detail(obj.id) : Werkzeug.detail(obj.id);
        };
      });
    });
  }

  /* ---------- Teilen / Speichern ---------- */
  function isNative() {
    return !!(window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
  }

  function blobToBase64(blob) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result).split(',')[1] || '');
      r.onerror = () => rej(r.error);
      r.readAsDataURL(blob);
    });
  }

  async function teilen(blob, filename, titel) {
    /* In der Android-App: Datei in den Zwischenspeicher schreiben und teilen */
    if (isNative() && Capacitor.Plugins && Capacitor.Plugins.Filesystem && Capacitor.Plugins.Share) {
      try {
        const base64 = await blobToBase64(blob);
        const res = await Capacitor.Plugins.Filesystem.writeFile({
          path: filename, data: base64, directory: 'CACHE'
        });
        await Capacitor.Plugins.Share.share({ title: titel || filename, files: [res.uri] });
        return true;
      } catch (e) {
        const msg = (e && e.message) || '';
        if (/cancel|abort|dismiss/i.test(msg)) return false;
        Util.toast('Teilen hat nicht geklappt');
        return false;
      }
    }
    try {
      const file = new File([blob], filename, { type: blob.type });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: titel || filename });
        return true;
      }
    } catch (e) { if (e && e.name === 'AbortError') return false; }

    /* Browser: Download anbieten – und als Notnagel den Inhalt zum Kopieren */
    const url = URL.createObjectURL(blob);
    const istBild = /^image\//.test(blob.type);
    const istText = /json|csv|text/.test(blob.type) && blob.size < 900000;
    const text = istText ? await blob.text() : '';
    Util.sheet(titel || filename, [
      '<p class="small muted" style="margin-top:-6px">' + Util.esc(filename) + '</p>',
      '<a class="btn btn-primary btn-block" href="' + url + '" download="' + Util.esc(filename) + '">Datei speichern</a>',
      istBild ? '<p class="small muted" style="margin-top:12px">Zum Sichern das Bild lange antippen und speichern.</p>' +
        '<img src="' + url + '" style="width:100%;border-radius:12px;background:#fff" alt="">' : '',
      istText ? '<p class="small muted" style="margin-top:12px">Falls der Browser das Speichern blockiert: Text markieren und kopieren.</p>' +
        '<textarea readonly style="height:150px;font-size:12px">' + Util.esc(text) + '</textarea>' : '',
      '<button class="btn btn-ghost btn-block" id="dlZu" style="margin-top:10px">Schließen</button>'
    ].join(''), el => {
      Util.$('#dlZu', el).onclick = () => { Util.closeSheet(); setTimeout(() => URL.revokeObjectURL(url), 1000); };
    });
    return true;
  }

  /* ---------- Start ---------- */
  function init() {
    Util.$$('#tabbar .tab').forEach(t => { t.onclick = () => go(t.dataset.tab); });
    Util.$('#scanBtn').onclick = scan;
    Util.$('#scanClose').onclick = () => Media.cancelScan();
    Util.$('#backBtn').onclick = () => { if (backRoute) go(backRoute); };
    Util.$('#sheet').onclick = e => { if (e.target.id === 'sheet') Util.closeSheet(); };

    /* Android-Zurück-Taste */
    if (window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.App) {
      Capacitor.Plugins.App.addListener('backButton', () => {
        if (!Util.$('#scanner').classList.contains('hidden')) { Media.cancelScan(); return; }
        if (!Util.$('#sheet').classList.contains('hidden')) { Util.closeSheet(); return; }
        if (backRoute) { go(backRoute); return; }
        if (route !== 'start') { go('start'); return; }
        Capacitor.Plugins.App.exitApp();
      });
    }
    document.addEventListener('keydown', e => {
      if (e.key !== 'Escape') return;
      if (!Util.$('#scanner').classList.contains('hidden')) Media.cancelScan();
      else if (!Util.$('#sheet').classList.contains('hidden')) Util.closeSheet();
      else if (backRoute) go(backRoute);
    });

    go('start');
  }

  const api = { go, paint, showBack, scan, handleCode, teilen, dashboard, isNative, route: 'start', init };
  return api;
})();

document.addEventListener('DOMContentLoaded', () => App.init());
